import { parentPort } from 'node:worker_threads';
import fs from 'fs';
import path from 'path';
import { pathToFileURL, fileURLToPath } from 'url';
import https from 'https';
import http from 'http';
import 'node:fs';
import 'node:path';
import 'node:url';

let sharpModule = null;
let searchPaths = [];
const SHARP_RUNTIME_DEPS_DIR = "runtime-deps";
function resolveSharpRuntimeDepsDir(dataDir) {
  const resolved = path.resolve(String(dataDir || "").trim());
  if (!resolved) return path.join(".", SHARP_RUNTIME_DEPS_DIR);
  return path.join(path.dirname(path.dirname(resolved)), SHARP_RUNTIME_DEPS_DIR);
}
function configureSharpRuntimePaths(paths) {
  const dataDir = String(paths.dataDir || "").trim();
  const pluginDir = String(paths.pluginDir || "").trim();
  const next = [];
  if (dataDir) next.push(resolveSharpRuntimeDepsDir(dataDir));
  if (pluginDir) next.push(path.resolve(pluginDir));
  searchPaths = next;
}
function fileExists(p) {
  try {
    return fs.existsSync(p);
  } catch {
    return false;
  }
}
function sharpEntryCandidates(baseDir) {
  const root = path.join(baseDir, "node_modules", "sharp");
  return [
    path.join(root, "lib", "index.js"),
    path.join(root, "lib", "sharp.js")
  ];
}
async function importSharpFromDir(baseDir) {
  for (const entry of sharpEntryCandidates(baseDir)) {
    if (!fileExists(entry)) continue;
    try {
      const mod = await import(pathToFileURL(entry).href);
      const factory = mod.default ?? mod;
      if (typeof factory === "function") return factory;
    } catch {
    }
  }
  return null;
}
async function loadSharp() {
  if (sharpModule) return sharpModule;
  for (const dir of searchPaths) {
    const loaded = await importSharpFromDir(dir);
    if (loaded) {
      sharpModule = loaded;
      return loaded;
    }
  }
  const mod = await import('sharp');
  sharpModule = mod.default ?? mod;
  return sharpModule;
}

const MENU_ICON_SVGS = {
  key: "M17 8h1a4 4 0 110 8h-1M15 8V6a4 4 0 00-8 0v2M9 8v10",
  shield: "M12 3l8 4v6c0 5-8 8-8 8s-8-3-8-8V7l8-4z",
  "user-add": ["M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2", "M9 11a4 4 0 100-8 4 4 0 000 8z", "M19 8v6", "M22 11h-6"],
  settings: "M12 15.5A3.5 3.5 0 1012 8.5a3.5 3.5 0 000 7zM19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z",
  music: "M9 18V5l12-2v13M9 13a3 3 0 100 6 3 3 0 000-6zM21 11a3 3 0 100 6 3 3 0 000-6z",
  video: "M15 10l4-2v8l-4-2V10zM5 6h10a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2z",
  account: ["M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2", "M12 11a4 4 0 100-8 4 4 0 000 8z"],
  "file-settings": "M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6zM14 2v6h6M12 18v-6M9 15h6",
  links: "M10 13a5 5 0 007.54.54l2-2a5 5 0 00-7.07-7.07l-1.17 1.17M14 11a5 5 0 00-7.54-.54l-2 2a5 5 0 007.07 7.07l1.17-1.17",
  fire: "M12 3c2 4 6 5 6 10a6 6 0 11-12 0c0-3 2-5 4-7 1 2 2 3 2 4z",
  qa: "M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2v10z",
  card: "M3 10h18M7 15h2M3 6a2 2 0 012-2h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V6z",
  calendar: ["M8 2v4M16 2v4", "M3 10h18", "M5 4h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V6a2 2 0 012-2z", "M9 16l2 2 4-4"],
  anchor: "M12 22V8M5 12H2a10 10 0 0020 0h-3M12 6a3 3 0 100-6 3 3 0 000 6z",
  "id-card": "M4 6h16v12H4V6zM8 10h8M8 14h5M12 6v12",
  bank: "M3 10h18M5 10V20M9 10V20M15 10V20M19 10V20M12 3l9 5H3l9-5z",
  dice: "M5 5h14v14H5V5zM9 9h.01M15 9h.01M9 15h.01M15 15h.01",
  "mail-send": "M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z",
  chat: "M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2v10z",
  heart: "M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z",
  trophy: "M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0V4zM5 4H3v2a3 3 0 003 3M19 4h2v2a3 3 0 01-3 3",
  mute: ["M11 5L6 9H2v6h4l5 4V5z", "M23 9l-6 6", "M17 9l6 6"],
  briefcase: ["M4 7h16v13H4V7z", "M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2", "M4 12h16"]
};
const MENU_BASIC_ITEMS = [
  { title: "授权系统", desc: "插件内置的授权系统", icon: "key" },
  { title: "群管系统", desc: "仅限于群内使用", icon: "shield" },
  { title: "邀人统计", desc: "开启后可记录邀请次数，并且可一系列控制", icon: "user-add" },
  { title: "事件管理", desc: "各种开关的管理及介绍", icon: "settings" },
  { title: "音乐系统", desc: "听歌的，共4种音源，可语音、链接、卡片返回", icon: "music" },
  { title: "视频菜单", desc: "接入了大量的视频接口，注：接口来源于网络", icon: "video" },
  { title: "账号设置", desc: "配置登录的机器人账号信息的，如头像昵称签名等", icon: "account" },
  { title: "插件配置", desc: "该功能仅配置MK的config.json文件", icon: "file-settings" },
  { title: "接口功能", desc: "这个是本插件接入的第三方接口，都会在里面", icon: "links" },
  { title: "管理续火", desc: "每日续火，需先开启相关事件，支持好友/群聊，支持图片或文案", icon: "fire" },
  { title: "问答系统", desc: "有模糊问答 和 精准问答，支持图片回复", icon: "qa" },
  { title: "发卡系统", desc: "全局发卡系统，可用于其他分发娱乐，使用归笺兑换，支持定价、改名等操作", icon: "card" }
];
const MENU_ENT_ITEMS = [
  { title: "签到", desc: "每日签到获取奖励", icon: "calendar" },
  { title: "钓鱼", desc: "通过「每日签到」可获取诱饵钓鱼哦～", icon: "anchor" },
  { title: "我的信息", desc: "查看游戏中你的信息", icon: "id-card" },
  { title: "银行系统", desc: "存钱的，有利润，非常建议把货币存进去", icon: "bank" },
  { title: "幸运轮盘", desc: "要来一把豪赌的轮盘吗！", icon: "dice" },
  { title: "漂流瓶", desc: "字面意思，不过没有隐私保护，直接公开瓶子主人", icon: "mail-send" },
  { title: "伪造聊天", desc: "目前版本仅支持纯文本伪造", icon: "chat" },
  { title: "群老婆", desc: "支持单群或全群", icon: "heart" },
  { title: "排行榜", desc: "各种类型的排行名单", icon: "trophy" },
  { title: "禁言卡", desc: "使用禁言卡@别人", icon: "mute" },
  { title: "打工", desc: "13个岗位各有独立工资公式；查看打工状态 / 结算工资", icon: "briefcase" }
];
function renderMenuIconForSharp(iconKey, x, y, boxSize, color) {
  const paths = MENU_ICON_SVGS[iconKey];
  if (!paths) return "";
  const inner = 18;
  const scale = inner / 24;
  const tx = x + (boxSize - inner) / 2;
  const ty = y + (boxSize - inner) / 2;
  const list = Array.isArray(paths) ? paths : [paths];
  const pathEls = list.map(
    (d) => `<path d="${d}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>`
  ).join("");
  return `<g transform="translate(${tx},${ty}) scale(${scale})">${pathEls}</g>`;
}

const SHARP_BG_DIM_CONFIG_KEY = "Sharp背景暗度";
const SHARP_BG_BLUR_CONFIG_KEY = "Sharp背景模糊";
const DEFAULT_SHARP_BG_DIM_PERCENT = 40;
const DEFAULT_SHARP_BG_BLUR = 0;
const MAX_SHARP_BG_BLUR = 30;
function parseSharpBgDimPercent(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return DEFAULT_SHARP_BG_DIM_PERCENT;
  return Math.min(100, Math.max(0, n));
}
function parseSharpBgBlurSigma(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return DEFAULT_SHARP_BG_BLUR;
  return Math.min(MAX_SHARP_BG_BLUR, Math.max(0, n));
}
function resolveSharpBgEffectsFromConfig(config) {
  const dimPct = parseSharpBgDimPercent(config?.[SHARP_BG_DIM_CONFIG_KEY]);
  const blurSigma = parseSharpBgBlurSigma(config?.[SHARP_BG_BLUR_CONFIG_KEY]);
  return {
    dimAlpha: dimPct / 100,
    blurSigma
  };
}
function loadSharpBgEffectsFromDataPath(dataPath) {
  const dir = String(dataPath || "").trim();
  if (!dir) return resolveSharpBgEffectsFromConfig(null);
  try {
    const cfgPath = path.join(dir, "config.json");
    if (!fs.existsSync(cfgPath)) return resolveSharpBgEffectsFromConfig(null);
    const raw = JSON.parse(fs.readFileSync(cfgPath, "utf-8"));
    return resolveSharpBgEffectsFromConfig(raw);
  } catch {
    return resolveSharpBgEffectsFromConfig(null);
  }
}
async function prepareSharpPhotoBackgroundLayer(sharp, bgBuf, width, height, effects) {
  let pipeline = sharp(bgBuf).resize(width, height, { fit: "cover", position: "centre" });
  if (effects.blurSigma > 0) {
    pipeline = pipeline.blur(effects.blurSigma);
  }
  return pipeline.ensureAlpha().png().toBuffer();
}
async function createSharpDimOverlayLayer(sharp, width, height, dimAlpha) {
  if (dimAlpha <= 0) return null;
  return sharp({
    create: {
      width,
      height,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: dimAlpha }
    }
  }).png().toBuffer();
}
async function applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath, effectsOverride) {
  const effects = loadSharpBgEffectsFromDataPath(String(dataPath || ""));
  const bgLayer = await prepareSharpPhotoBackgroundLayer(sharp, bgBuf, width, height, effects);
  composites.push({ input: bgLayer, top: 0, left: 0 });
  const dimOverlay = await createSharpDimOverlayLayer(sharp, width, height, effects.dimAlpha);
  if (dimOverlay) composites.push({ input: dimOverlay, top: 0, left: 0 });
}

const SHARP_TEXT_COLOR_CONFIG_KEY = "Sharp全局字体色";
const HEX_COLOR_RE = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/;
function parseSharpTextColor(value) {
  const s = String(value ?? "").trim();
  if (!s) return null;
  if (!HEX_COLOR_RE.test(s)) return null;
  if (s.length === 4) {
    const r = s[1];
    const g = s[2];
    const b = s[3];
    return `#${r}${r}${g}${g}${b}${b}`;
  }
  return s.length === 9 ? s.slice(0, 7) : s;
}
function resolveSharpTextColorFromConfig(config) {
  return parseSharpTextColor(config?.[SHARP_TEXT_COLOR_CONFIG_KEY]);
}
function loadSharpTextColorFromDataPath(dataPath) {
  const dir = String(dataPath || "").trim();
  if (!dir) return null;
  try {
    const cfgPath = path.join(dir, "config.json");
    if (!fs.existsSync(cfgPath)) return null;
    const raw = JSON.parse(fs.readFileSync(cfgPath, "utf-8"));
    return resolveSharpTextColorFromConfig(raw);
  } catch {
    return null;
  }
}
function resolveSharpTextFill(custom, fallback) {
  return custom ?? fallback;
}

function escapeXml$b(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function wrapText$2(text, maxChars) {
  const s = String(text || "").trim();
  if (!s) return [""];
  const lines = [];
  let cur = "";
  for (const ch of s) {
    if (cur.length >= maxChars) {
      lines.push(cur);
      cur = "";
    }
    cur += ch;
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 3);
}
function fetchUrlBuffer$6(url, timeoutMs = 15e3) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === "https:" ? https : http;
    const req = lib.get(
      url,
      { timeout: timeoutMs, headers: { "User-Agent": "MKbot-SharpRender/1.0" } },
      (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          fetchUrlBuffer$6(res.headers.location, timeoutMs).then(resolve).catch(reject);
          return;
        }
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode}`));
          res.resume();
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
        res.on("end", () => resolve(Buffer.concat(chunks)));
        res.on("error", reject);
      }
    );
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy(new Error("timeout"));
    });
  });
}
async function loadBackgroundSource(options, pluginDir, dataPath) {
  const width = options.width ?? 1680;
  const height = options.height ?? 1010;
  const landscape = width >= height;
  const candidates = [];
  const push = (v) => {
    const s = String(v || "").trim();
    if (s && !candidates.includes(s)) candidates.push(s);
  };
  if (landscape) {
    push(options.bgLocalPath);
  } else {
    push(options.bgLocalPortraitPath);
    push(options.bgLocalPath);
  }
  const localNames = landscape ? ["heng.jpg", "heng.jpeg", "heng.png", "heng.webp"] : ["shu.jpg", "shu.jpeg", "shu.png", "shu.webp", "heng.jpg"];
  const roots = [
    path.join(String(pluginDir || "").trim(), "默认资源", "image")
  ];
  for (const root of roots) {
    if (!String(root || "").trim()) continue;
    for (const name of localNames) {
      push(path.join(root, name));
    }
  }
  push(options.bgUrl);
  push(landscape ? options.bgLandscape : options.bgPortrait);
  push(options.bgLandscape);
  push(options.bgPortrait);
  for (const src of candidates) {
    try {
      if (/^file:\/\//i.test(src)) {
        const abs2 = fileURLToPath(src);
        if (fs.existsSync(abs2)) return fs.readFileSync(abs2);
        continue;
      }
      if (/^https?:\/\//i.test(src)) {
        const buf = await fetchUrlBuffer$6(src, 2e4);
        if (buf.length > 0) return buf;
        continue;
      }
      const abs = path.isAbsolute(src) ? src : path.resolve(src);
      if (fs.existsSync(abs)) {
        return fs.readFileSync(abs);
      }
    } catch (_e) {
    }
  }
  return null;
}
function buildMenuSvg(width, height, theme, customText) {
  const isLight = theme === "light";
  const titleColor = resolveSharpTextFill(customText, isLight ? "#3a2f1c" : "#fff3dc");
  const labelColor = resolveSharpTextFill(customText, isLight ? "rgba(42,36,24,0.78)" : "rgba(255,255,255,0.88)");
  const groupBg = isLight ? "rgba(255,255,255,0.22)" : "rgba(0,0,0,0.14)";
  const groupColor = resolveSharpTextFill(customText, isLight ? "#3a2f1c" : "#fff3dc");
  const boxBg = isLight ? "rgba(255,255,255,0.16)" : "rgba(255,255,255,0.05)";
  const boxBorder = isLight ? "rgba(255,255,255,0.45)" : "rgba(255,255,255,0.38)";
  const cellBg = isLight ? "rgba(255,255,255,0.12)" : "transparent";
  const cellAltBg = isLight ? "rgba(255,255,255,0.18)" : "rgba(255,255,255,0.025)";
  const itemTitle = resolveSharpTextFill(customText, isLight ? "#2f2718" : "#fff6e8");
  const itemDesc = isLight ? "rgba(42,36,24,0.78)" : "rgba(255,255,255,0.92)";
  const iconBg = isLight ? "rgba(255,255,255,0.38)" : "rgba(255,255,255,0.1)";
  const iconBorder = isLight ? "rgba(255,255,255,0.72)" : "rgba(255,255,255,0.42)";
  const iconStroke = resolveSharpTextFill(customText, isLight ? "#6b5434" : "#fff6e8");
  const footerColor = "rgba(238,238,238,0.35)";
  const padX = 20;
  const contentW = width - padX * 2;
  const cols = width >= 560 ? 3 : width >= 380 ? 2 : 1;
  const colW = contentW / cols;
  const rowH = 88;
  const iconSize = 32;
  let y = 56;
  const parts = [];
  parts.push(
    `<text x="${width / 2}" y="${y}" text-anchor="middle" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="46" font-weight="800" fill="${titleColor}">使用帮助</text>`
  );
  y += 38;
  parts.push(
    `<text x="${width / 2}" y="${y}" text-anchor="middle" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="16" fill="${labelColor}">MK-Bot · NapCat 综合娱乐与群管</text>`
  );
  y += 28;
  const renderSection = (groupTitle, items) => {
    const rows = Math.ceil(items.length / cols);
    const groupH = 42 + rows * rowH + 8;
    const boxX = padX;
    const boxY = y;
    parts.push(
      `<rect x="${boxX}" y="${boxY}" width="${contentW}" height="${groupH}" rx="18" ry="18" fill="${boxBg}" stroke="${boxBorder}" stroke-width="1"/>`
    );
    parts.push(
      `<rect x="${boxX}" y="${boxY}" width="${contentW}" height="38" rx="18" ry="18" fill="${groupBg}"/>`
    );
    parts.push(
      `<text x="${boxX + 18}" y="${boxY + 26}" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="16" font-weight="700" fill="${groupColor}">${escapeXml$b(groupTitle)}</text>`
    );
    const gridTop = boxY + 42;
    items.forEach((item, idx) => {
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const cx = boxX + col * colW;
      const cy = gridTop + row * rowH;
      const alt = row % 2 === 1;
      parts.push(
        `<rect x="${cx + 1}" y="${cy + 1}" width="${colW - 2}" height="${rowH - 2}" fill="${alt ? cellAltBg : cellBg}" stroke="${isLight ? "rgba(255,255,255,0.28)" : "rgba(255,255,255,0.12)"}" stroke-width="1"/>`
      );
      const ix = cx + 10;
      const iy = cy + 12;
      parts.push(
        `<rect x="${ix}" y="${iy}" width="${iconSize}" height="${iconSize}" rx="7" fill="${iconBg}" stroke="${iconBorder}" stroke-width="1"/>`
      );
      parts.push(renderMenuIconForSharp(item.icon, ix, iy, iconSize, iconStroke));
      const tx = ix + iconSize + 10;
      parts.push(
        `<text x="${tx}" y="${iy + 16}" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="14" font-weight="700" fill="${itemTitle}">${escapeXml$b(item.title)}</text>`
      );
      const descLines = wrapText$2(item.desc, cols === 1 ? 28 : cols === 2 ? 18 : 14);
      descLines.forEach((line, li) => {
        parts.push(
          `<text x="${tx}" y="${iy + 34 + li * 16}" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="11" fill="${itemDesc}">${escapeXml$b(line)}</text>`
        );
      });
    });
    y += groupH + 14;
  };
  renderSection("基础功能", MENU_BASIC_ITEMS);
  renderSection("娱乐功能", MENU_ENT_ITEMS);
  parts.push(
    `<text x="${width / 2}" y="${height - 18}" text-anchor="middle" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="11" fill="${footerColor}" letter-spacing="2">发送「菜单」或「/MK」查看本帮助</text>`
  );
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
  <defs>
    <linearGradient id="topFade" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="rgba(0,0,0,0.08)"/>
      <stop offset="100%" stop-color="rgba(0,0,0,0)"/>
    </linearGradient>
  </defs>
  ${parts.join("\n  ")}
  <rect x="0" y="0" width="${width}" height="220" fill="url(#topFade)"/>
</svg>`;
}
async function fitCompositeLayer$5(sharp, input, width, height) {
  return sharp(input).resize(width, height, { fit: "fill" }).ensureAlpha().png().toBuffer();
}
async function renderMenuWithSharpImpl(pluginDir, dataPath, options, logger) {
  const width = options.width ?? 1680;
  const height = options.height ?? 1010;
  const theme = String(options.uiTheme || "0").trim() === "1" ? "light" : "clear";
  try {
    const sharp = await loadSharp();
    const bgBuf = await loadBackgroundSource(options, pluginDir, dataPath);
    const composites = [];
    if (bgBuf && bgBuf.length > 0) {
      await applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath);
    }
    const customText = loadSharpTextColorFromDataPath(dataPath);
    const svg = buildMenuSvg(width, height, theme, customText);
    const uiLayer = await fitCompositeLayer$5(sharp, Buffer.from(svg), width, height);
    composites.push({ input: uiLayer, top: 0, left: 0 });
    let canvas = sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 15, g: 25, b: 35, alpha: 1 }
      }
    });
    if (composites.length > 0) {
      canvas = canvas.composite(composites);
    }
    const out = await canvas.png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

const API_INTERFACE_MENU_SECTIONS = [
  {
    title: "API接口功能",
    items: [
      { name: "图片菜单", icon: "video" },
      { name: "三角洲密码", icon: "key" },
      { name: "EPIC免费游戏", icon: "dice" },
      { name: "搜饰品[关键词]", icon: "qa" },
      { name: "发病文学[对象名]", icon: "chat" },
      { name: "查MC服务器[IP/域名]", icon: "settings" }
    ]
  },
  {
    title: "表情包系统",
    items: [
      { name: "爬", note: "静态图，随机模板", icon: "heart", tag: "静态" },
      { name: "顶", note: "GIF", icon: "heart", tag: "GIF" },
      { name: "啃", note: "GIF", icon: "heart", tag: "GIF" },
      { name: "摸头", note: "GIF", icon: "heart", tag: "GIF" },
      { name: "吃", note: "GIF", icon: "heart", tag: "GIF" },
      { name: "吸", note: "GIF", icon: "heart", tag: "GIF" },
      { name: "啾", note: "GIF", icon: "heart", tag: "GIF" },
      { name: "挠头", note: "GIF", icon: "heart", tag: "GIF" },
      { name: "贴贴", note: "GIF，需 @ 对方", icon: "heart", tag: "@" },
      { name: "戒导", note: "证书 PNG，可带日期", icon: "card", tag: "PNG" },
      { name: "二次元入口", note: "PNG", icon: "links", tag: "PNG" },
      { name: "上瘾", note: "PNG", icon: "heart", tag: "PNG" },
      { name: "别碰", note: "PNG", icon: "shield", tag: "PNG" },
      { name: "捣", note: "GIF", icon: "heart", tag: "GIF" },
      { name: "灰飞烟灭", note: "GIF", icon: "fire", tag: "GIF" },
      { name: "卖掉了", note: "PNG", icon: "fire", tag: "PNG" },
      { name: "嘲讽", note: "PNG", icon: "chat", tag: "PNG" },
      { name: "想什么", note: "PNG", icon: "qa", tag: "PNG" },
      { name: "我想上的", note: "PNG", icon: "heart", tag: "PNG" },
      { name: "你不懂啦", note: "PNG", icon: "chat", tag: "PNG" }
    ]
  }
];
const API_INTERFACE_MENU_FOOTER = "事件管理开启「表情制作」；可 @ 指定头像；贴贴必须 @";

const TAG_COLORS = {
  GIF: { bg: "rgba(255,138,101,0.22)", stroke: "rgba(255,138,101,0.55)", text: "#ffc9b8" },
  PNG: { bg: "rgba(129,212,250,0.2)", stroke: "rgba(129,212,250,0.5)", text: "#c8ecff" },
  静态: { bg: "rgba(186,255,168,0.18)", stroke: "rgba(186,255,168,0.45)", text: "#d9ffd0" },
  "@": { bg: "rgba(255,213,79,0.2)", stroke: "rgba(255,213,79,0.5)", text: "#ffe9a8" }
};
function escapeXml$a(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function wrapText$1(text, maxChars, maxLines = 2) {
  const s = String(text || "").trim();
  if (!s) return [""];
  const lines = [];
  let cur = "";
  for (const ch of s) {
    if (cur.length >= maxChars) {
      lines.push(cur);
      cur = "";
      if (lines.length >= maxLines) break;
    }
    cur += ch;
  }
  if (cur && lines.length < maxLines) lines.push(cur);
  return lines.length ? lines : [""];
}
function fetchUrlBuffer$5(url, timeoutMs = 15e3) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https") ? https : http;
    const req = lib.get(
      url,
      { timeout: timeoutMs, headers: { "User-Agent": "MKbot-ApiMenuSharp/1.0" } },
      (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          fetchUrlBuffer$5(res.headers.location, timeoutMs).then(resolve).catch(reject);
          return;
        }
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode}`));
          res.resume();
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
        res.on("end", () => resolve(Buffer.concat(chunks)));
        res.on("error", reject);
      }
    );
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("timeout")));
  });
}
async function loadBackgroundBuffer(options) {
  const candidates = [];
  const push = (v) => {
    const s = String(v || "").trim();
    if (s && !candidates.includes(s)) candidates.push(s);
  };
  push(options.bgLocalPath);
  const roots = [
    path.join(String(options.dataPath || "").trim(), "默认资源", "image"),
    path.join(String(options.pluginDir || "").trim(), "data", "默认资源", "image")
  ];
  for (const root of roots) {
    if (!root.trim()) continue;
    for (const name of ["heng.jpg", "heng.jpeg", "heng.png", "heng.webp"]) {
      push(path.join(root, name));
    }
  }
  for (const src of candidates) {
    try {
      if (/^file:\/\//i.test(src)) {
        const abs2 = fileURLToPath(src);
        if (fs.existsSync(abs2)) return fs.readFileSync(abs2);
        continue;
      }
      if (/^https?:\/\//i.test(src)) {
        const buf = await fetchUrlBuffer$5(src, 2e4);
        if (buf.length > 0) return buf;
        continue;
      }
      const abs = path.isAbsolute(src) ? src : path.resolve(src);
      if (fs.existsSync(abs)) return fs.readFileSync(abs);
    } catch {
    }
  }
  return null;
}
function calcSectionGrid(section, cols, rowH) {
  const rows = Math.ceil(section.items.length / cols);
  return 42 + rows * rowH + 10;
}
function calcMenuHeight(width, cols, rowH) {
  const padY = 36;
  const titleBlock = 86;
  const sectionGap = 16;
  const footerH = 40;
  let body = 0;
  for (const section of API_INTERFACE_MENU_SECTIONS) {
    body += calcSectionGrid(section, cols, rowH) + sectionGap;
  }
  return padY + titleBlock + body + footerH + padY;
}
function renderTagPill(x, y, tag) {
  const colors = TAG_COLORS[tag] || TAG_COLORS.GIF;
  const w = tag.length <= 2 ? 34 : 44;
  return [
    `<rect x="${x}" y="${y}" width="${w}" height="18" rx="9" fill="${colors.bg}" stroke="${colors.stroke}" stroke-width="1"/>`,
    `<text x="${x + w / 2}" y="${y + 13}" text-anchor="middle" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="10" font-weight="700" fill="${colors.text}">${escapeXml$a(tag)}</text>`
  ].join("");
}
function buildApiInterfaceMenuSvg(width, height, customText) {
  const titleColor = resolveSharpTextFill(customText, "#fff3dc");
  const labelColor = resolveSharpTextFill(customText, "rgba(255,255,255,0.88)");
  const groupBg = "rgba(0,0,0,0.14)";
  const groupColor = resolveSharpTextFill(customText, "#fff3dc");
  const boxBg = "rgba(255,255,255,0.05)";
  const boxBorder = "rgba(255,255,255,0.38)";
  const cellBg = "transparent";
  const cellAltBg = "rgba(255,255,255,0.025)";
  const itemTitle = resolveSharpTextFill(customText, "#fff6e8");
  const itemDesc = "rgba(255,255,255,0.82)";
  const iconBg = "rgba(255,255,255,0.1)";
  const iconBorder = "rgba(255,255,255,0.42)";
  const iconStroke = resolveSharpTextFill(customText, "#fff6e8");
  const footerColor = "rgba(238,238,238,0.35)";
  const padX = 24;
  const contentW = width - padX * 2;
  const cols = width >= 900 ? 3 : width >= 620 ? 2 : 1;
  const colW = contentW / cols;
  const rowH = cols === 3 ? 78 : cols === 2 ? 82 : 72;
  const iconSize = 30;
  const parts = [];
  let y = 40;
  parts.push(
    `<text x="${width / 2}" y="${y}" text-anchor="middle" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="42" font-weight="800" fill="${titleColor}">接口功能</text>`
  );
  y += 36;
  parts.push(
    `<text x="${width / 2}" y="${y}" text-anchor="middle" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="15" fill="${labelColor}">MK-Bot · 第三方 API 与表情包指令</text>`
  );
  y += 34;
  const renderGridSection = (groupTitle, items) => {
    const rows = Math.ceil(items.length / cols);
    const groupH = 42 + rows * rowH + 10;
    const boxX = padX;
    const boxY = y;
    parts.push(
      `<rect x="${boxX}" y="${boxY}" width="${contentW}" height="${groupH}" rx="18" ry="18" fill="${boxBg}" stroke="${boxBorder}" stroke-width="1"/>`
    );
    parts.push(
      `<rect x="${boxX}" y="${boxY}" width="${contentW}" height="38" rx="18" ry="18" fill="${groupBg}"/>`
    );
    parts.push(
      `<text x="${boxX + 18}" y="${boxY + 26}" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="16" font-weight="700" fill="${groupColor}">${escapeXml$a(groupTitle)}</text>`
    );
    const gridTop = boxY + 42;
    items.forEach((item, idx) => {
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const cx = boxX + col * colW;
      const cy = gridTop + row * rowH;
      const alt = row % 2 === 1;
      parts.push(
        `<rect x="${cx + 1}" y="${cy + 1}" width="${colW - 2}" height="${rowH - 2}" fill="${alt ? cellAltBg : cellBg}" stroke="rgba(255,255,255,0.12)" stroke-width="1"/>`
      );
      const ix = cx + 12;
      const iy = cy + 14;
      parts.push(
        `<rect x="${ix}" y="${iy}" width="${iconSize}" height="${iconSize}" rx="8" fill="${iconBg}" stroke="${iconBorder}" stroke-width="1"/>`
      );
      if (item.icon) {
        parts.push(renderMenuIconForSharp(item.icon, ix, iy, iconSize, iconStroke));
      }
      const tx = ix + iconSize + 10;
      const titleLines = wrapText$1(item.name, cols === 1 ? 24 : cols === 2 ? 14 : 10, 1);
      parts.push(
        `<text x="${tx}" y="${iy + 16}" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="14" font-weight="700" fill="${itemTitle}">${escapeXml$a(titleLines[0])}</text>`
      );
      if (item.tag) {
        parts.push(renderTagPill(cx + colW - 48, cy + 10, item.tag));
      }
      const descSource = item.note || (item.tag ? "" : "");
      if (descSource) {
        const descLines = wrapText$1(descSource, cols === 1 ? 28 : cols === 2 ? 16 : 12, 2);
        descLines.forEach((line, li) => {
          parts.push(
            `<text x="${tx}" y="${iy + 34 + li * 15}" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="11" fill="${itemDesc}">${escapeXml$a(line)}</text>`
          );
        });
      } else if (!item.tag && cols >= 2) {
        parts.push(
          `<text x="${tx}" y="${iy + 34}" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="11" fill="${itemDesc}">发送指令即可使用</text>`
        );
      }
    });
    y += groupH + 16;
  };
  for (const section of API_INTERFACE_MENU_SECTIONS) {
    renderGridSection(section.title, section.items);
  }
  parts.push(
    `<text x="${width / 2}" y="${height - 18}" text-anchor="middle" font-family="Microsoft YaHei, Noto Sans SC, sans-serif" font-size="11" fill="${footerColor}" letter-spacing="1">${escapeXml$a(API_INTERFACE_MENU_FOOTER)}</text>`
  );
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
  <defs>
    <linearGradient id="topFade" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="rgba(0,0,0,0.1)"/>
      <stop offset="100%" stop-color="rgba(0,0,0,0)"/>
    </linearGradient>
  </defs>
  ${parts.join("\n  ")}
  <rect x="0" y="0" width="${width}" height="180" fill="url(#topFade)"/>
</svg>`;
}
async function fitCompositeLayer$4(sharp, input, width, height) {
  return sharp(input).resize(width, height, { fit: "fill" }).ensureAlpha().png().toBuffer();
}
async function renderApiInterfaceMenuWithSharpImpl(options = {}, logger) {
  const width = options.width ?? 1080;
  const cols = width >= 900 ? 3 : width >= 620 ? 2 : 1;
  const rowH = cols === 3 ? 78 : cols === 2 ? 82 : 72;
  const height = calcMenuHeight(width, cols, rowH);
  const dataPath = String(options.dataPath || "").trim();
  try {
    const sharp = await loadSharp();
    const composites = [];
    const bgBuf = await loadBackgroundBuffer(options);
    if (bgBuf && bgBuf.length > 0) {
      await applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath);
    }
    const customText = loadSharpTextColorFromDataPath(dataPath);
    const svg = buildApiInterfaceMenuSvg(width, height, customText);
    const uiLayer = await fitCompositeLayer$4(sharp, Buffer.from(svg), width, height);
    composites.push({ input: uiLayer, top: 0, left: 0 });
    let canvas = sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 15, g: 25, b: 35, alpha: 1 }
      }
    });
    if (composites.length > 0) {
      canvas = canvas.composite(composites);
    }
    const out = await canvas.png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

function escapeXml$9(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function wrapText(text, maxChars, maxLines = 6) {
  const s = String(text || "").trim();
  if (!s) return [""];
  const lines = [];
  let cur = "";
  for (const ch of s) {
    if (cur.length >= maxChars) {
      lines.push(cur);
      cur = "";
      if (lines.length >= maxLines) break;
    }
    cur += ch;
  }
  if (cur && lines.length < maxLines) lines.push(cur);
  return lines.length ? lines : [""];
}
function fetchUrlBuffer$4(url, timeoutMs = 2e4) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https") ? https : http;
    const req = lib.get(
      url,
      { timeout: timeoutMs, headers: { "User-Agent": "MKbot-FortuneSharp/1.0" } },
      (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          fetchUrlBuffer$4(res.headers.location, timeoutMs).then(resolve).catch(reject);
          return;
        }
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode}`));
          res.resume();
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
        res.on("end", () => resolve(Buffer.concat(chunks)));
        res.on("error", reject);
      }
    );
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("timeout")));
  });
}
function decodeDataUrl$1(dataUrl) {
  const m = String(dataUrl || "").match(/^data:[^;]+;base64,(.+)$/i);
  if (!m) return null;
  try {
    return Buffer.from(m[1], "base64");
  } catch {
    return null;
  }
}
async function loadFortuneBackground(card, pluginDir, dataPath) {
  const candidates = [];
  const push = (v) => {
    const s = String(v || "").trim();
    if (s && !candidates.includes(s)) candidates.push(s);
  };
  push(card.backgroundImageUrl);
  const imageName = String(card.image_name || "").trim();
  if (imageName) {
    if (path.isAbsolute(imageName)) push(imageName);
    const roots = [
      path.join(String(dataPath || "").trim(), "默认资源", "image"),
      path.join(String(pluginDir || "").trim(), "data", "默认资源", "image")
    ];
    for (const root of roots) {
      if (!root.trim()) continue;
      push(path.join(root, imageName));
    }
  }
  for (const src of candidates) {
    try {
      if (/^data:/i.test(src)) {
        const buf = decodeDataUrl$1(src);
        if (buf && buf.length) return buf;
        continue;
      }
      if (/^file:\/\//i.test(src)) {
        const abs = fileURLToPath(src);
        if (fs.existsSync(abs)) return fs.readFileSync(abs);
        continue;
      }
      if (/^https?:\/\//i.test(src)) {
        const buf = await fetchUrlBuffer$4(src, 25e3);
        if (buf.length > 0) return buf;
        continue;
      }
      if (fs.existsSync(src)) return fs.readFileSync(src);
    } catch (_e) {
    }
  }
  return null;
}
function calcFortuneCardLayout(width, height, unSignText) {
  const cardW = Math.min(480, width - 40);
  const cardX = (width - cardW) / 2;
  const bottomPad = 50;
  const subLines = wrapText(unSignText, 26, 6);
  const cardH = 30 + 88 + 25 + 54 + subLines.length * 24 + 16 + 48 + 30;
  const cardY = height - bottomPad - cardH;
  return { cardW, cardX, cardY, cardH, subLines };
}
function buildFortuneOverlaySvg(width, height, card, customText) {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const accent = "#FFB6C1";
  const mainFill = resolveSharpTextFill(customText, "#ffffff");
  const glass = "rgba(15,15,18,0.5)";
  const title = escapeXml$9(card.Sorte || "大吉");
  const stars = escapeXml$9(card.Estrelas || "★★★★★★★");
  const time = escapeXml$9(card.time || "");
  escapeXml$9(card.signText || "福星高照，万事如意");
  const unSignText = String(card.unSignText || "此签为大吉之兆");
  const { cardW, cardX, cardY, cardH, subLines } = calcFortuneCardLayout(width, height, unSignText);
  const pad = 30;
  const avatarSize = 80;
  const avatarX = cardX + pad;
  const avatarY = cardY + pad;
  const infoX = avatarX + avatarSize + 18;
  const infoTimeY = avatarY + 18;
  const infoTitleY = avatarY + 44;
  const infoStarsY = avatarY + 72;
  const parts = [];
  parts.push(
    `<rect x="${cardX}" y="${cardY}" width="${cardW}" height="${cardH}" rx="35" ry="35" fill="${glass}" stroke="rgba(255,255,255,0.12)" stroke-width="1"/>`
  );
  parts.push(
    `<circle cx="${avatarX + avatarSize / 2}" cy="${avatarY + avatarSize / 2}" r="${avatarSize / 2 + 1.5}" fill="none" stroke="#ffffff" stroke-width="3"/>`
  );
  parts.push(
    `<text x="${infoX}" y="${infoTimeY}" font-family="${font}" font-size="13" font-weight="900" fill="${accent}" letter-spacing="1">time:${time}</text>`
  );
  parts.push(
    `<text x="${infoX}" y="${infoTitleY}" font-family="${font}" font-size="26" font-weight="700" fill="${mainFill}">${title}</text>`
  );
  parts.push(
    `<text x="${infoX}" y="${infoStarsY}" font-family="${font}" font-size="18" fill="${accent}">${stars}</text>`
  );
  const mainTop = avatarY + avatarSize + 25;
  const barX = cardX + pad;
  const textX = barX + 16;
  parts.push(
    `<rect x="${barX}" y="${mainTop + 2}" width="4" height="24" rx="2" fill="#ffffff" opacity="0.95"/>`
  );
  const signLines = wrapText(card.signText || "", 22, 2);
  signLines.forEach((line, i) => {
    parts.push(
      `<text x="${textX}" y="${mainTop + 20 + i * 26}" font-family="${font}" font-size="19" font-weight="600" fill="${mainFill}">${escapeXml$9(line)}</text>`
    );
  });
  const subTop = mainTop + 20 + signLines.length * 26 + 14;
  const subX = cardX + pad + 17;
  parts.push(
    `<line x1="${cardX + pad}" y1="${subTop - 8}" x2="${cardX + pad}" y2="${subTop - 8 + subLines.length * 24 + 8}" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>`
  );
  subLines.forEach((line, i) => {
    parts.push(
      `<text x="${subX}" y="${subTop + i * 24}" font-family="${font}" font-size="15" fill="rgba(255,255,255,0.7)">${escapeXml$9(line)}</text>`
    );
  });
  const noteY = cardY + cardH - 22;
  parts.push(
    `<text x="${cardX + cardW / 2}" y="${noteY}" text-anchor="middle" font-family="${font}" font-size="11" fill="rgba(255,255,255,0.3)" letter-spacing="2">本内容为虚拟生成，切勿迷信！</text>`
  );
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${parts.join("\n")}</svg>`;
}
async function roundAvatar$4(sharp, buf, size) {
  try {
    const mask = Buffer.from(
      `<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="white"/></svg>`
    );
    return sharp(buf).resize(size, size, { fit: "cover" }).ensureAlpha().composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
  } catch {
    return null;
  }
}
async function renderFortuneWithSharpImpl(options, logger) {
  const width = options.width ?? 720;
  const height = options.height ?? 1280;
  const card = options.card || {};
  const pluginDir = String(options.pluginDir || "").trim();
  const dataPath = String(options.dataPath || "").trim();
  try {
    const sharp = await loadSharp();
    const bgBuf = await loadFortuneBackground(card, pluginDir, dataPath);
    const composites = [];
    if (bgBuf && bgBuf.length > 0) {
      await applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath);
    } else {
      const fallback = await sharp({
        create: {
          width,
          height,
          channels: 3,
          background: { r: 255, g: 240, b: 243 }
        }
      }).png().toBuffer();
      composites.push({ input: fallback, top: 0, left: 0 });
      logger?.warn?.("[Sharp渲染] 今日运势背景图不可用，已使用默认底色");
    }
    const customText = loadSharpTextColorFromDataPath(dataPath);
    const overlaySvg = buildFortuneOverlaySvg(width, height, card, customText);
    const overlayLayer = await sharp(Buffer.from(overlaySvg)).png().toBuffer();
    composites.push({ input: overlayLayer, top: 0, left: 0 });
    const { cardX, cardY } = calcFortuneCardLayout(width, height, String(card.unSignText || ""));
    const avatarUrl = `https://q4.qlogo.cn/g?b=qq&nk=${card.qq || ""}&s=5`;
    try {
      const avatarBuf = await fetchUrlBuffer$4(avatarUrl, 1e4);
      if (avatarBuf.length > 0) {
        const rounded = await roundAvatar$4(sharp, avatarBuf, 80);
        if (rounded) {
          composites.push({ input: rounded, top: Math.round(cardY + 30), left: Math.round(cardX + 30) });
        }
      }
    } catch (_e) {
    }
    const out = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 0, g: 0, b: 0, alpha: 1 }
      }
    }).composite(composites).png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

const STATUS_BG_REMOTE_URL = "http://xn--mk-ub3cl61ae1v.xn--c5w857b.xn--fiqs8s/mkbot/image/yunxing.jpg";
function escapeXml$8(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function truncateText$6(text, maxLen) {
  const s = String(text || "").trim();
  if (s.length <= maxLen) return s;
  return `${s.slice(0, maxLen - 1)}…`;
}
function toPercentNum(v) {
  const n = Number(String(v ?? "").replace("%", "").trim());
  return Number.isFinite(n) ? Math.min(100, Math.max(0, n)) : 0;
}
function usageColor(percent) {
  if (percent < 50) return "#4CAF50";
  if (percent < 75) return "#FF9800";
  return "#F44336";
}
function usageGlowId(percent) {
  if (percent < 50) return "pctGlowGreen";
  if (percent < 75) return "pctGlowOrange";
  return "pctGlowRed";
}
function fetchUrlBuffer$3(url, timeoutMs = 2e4) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https") ? https : http;
    const req = lib.get(
      url,
      { timeout: timeoutMs, headers: { "User-Agent": "MKbot-StatusSharp/1.0" } },
      (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          fetchUrlBuffer$3(res.headers.location, timeoutMs).then(resolve).catch(reject);
          return;
        }
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode}`));
          res.resume();
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
        res.on("end", () => resolve(Buffer.concat(chunks)));
        res.on("error", reject);
      }
    );
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("timeout")));
  });
}
function decodeDataUrl(dataUrl) {
  const m = String(dataUrl || "").match(/^data:[^;]+;base64,(.+)$/i);
  if (!m) return null;
  try {
    return Buffer.from(m[1], "base64");
  } catch {
    return null;
  }
}
async function loadStatusBackground(backgroundImageUrl, bgLocalPath, pluginDir, pluginPath, dataPath) {
  const candidates = [];
  const push = (v) => {
    const s = String(v || "").trim();
    if (s && !candidates.includes(s)) candidates.push(s);
  };
  push(bgLocalPath);
  const localNames = ["运行状态.jpg", "运行状态.jpeg", "运行状态.png", "运行状态.webp", "yunxing.jpg"];
  const roots = [
    path.join(String(dataPath || "").trim(), "默认资源", "image"),
    path.join(String(pluginPath || "").trim(), "data", "默认资源", "image"),
    path.join(String(pluginDir || "").trim(), "data", "默认资源", "image")
  ];
  for (const root of roots) {
    if (!String(root || "").trim()) continue;
    for (const name of localNames) {
      push(path.join(root, name));
    }
  }
  push(backgroundImageUrl);
  if (backgroundImageUrl !== STATUS_BG_REMOTE_URL) {
    push(STATUS_BG_REMOTE_URL);
  }
  for (const src of candidates) {
    try {
      if (/^data:/i.test(src)) {
        const buf = decodeDataUrl(src);
        if (buf && buf.length) return buf;
        continue;
      }
      if (/^file:\/\//i.test(src)) {
        const abs = fileURLToPath(src);
        if (fs.existsSync(abs)) return fs.readFileSync(abs);
        continue;
      }
      if (/^https?:\/\//i.test(src)) {
        const buf = await fetchUrlBuffer$3(src, 12e3);
        if (buf.length > 0) return buf;
        continue;
      }
      if (fs.existsSync(src)) return fs.readFileSync(src);
    } catch (_e) {
    }
  }
  return null;
}
function gaugeSvg(cx, cy, outerR, percent, color, glowId, label) {
  const strokeW = 12;
  const r = outerR - strokeW / 2;
  const circ = 2 * Math.PI * r;
  const arcLen = circ * (percent / 100);
  const innerR = outerR - 14;
  const pctText = `${percent.toFixed(percent % 1 === 0 ? 0 : 1)}%`;
  return `
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(255,255,255,0.22)" stroke-width="${strokeW}"/>
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${color}" stroke-width="${strokeW}"
      stroke-dasharray="${arcLen} ${circ - arcLen}" stroke-linecap="round"
      transform="rotate(-90 ${cx} ${cy})"/>
    <circle cx="${cx}" cy="${cy}" r="${innerR}" fill="rgba(255,255,255,0.95)"/>
    <text x="${cx}" y="${cy + 8}" text-anchor="middle" font-size="22" font-weight="bold" fill="#333" filter="url(#${glowId})">${pctText}</text>
    <text x="${cx}" y="${cy + outerR + 24}" text-anchor="middle" font-size="14" fill="rgba(255,255,255,0.85)" font-weight="500">${escapeXml$8(label)}</text>
  `;
}
function glassRect$2(x, y, w, h, rx = 15) {
  return `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" ry="${rx}" fill="rgba(255,255,255,0.15)" stroke="rgba(255,255,255,0.22)" stroke-width="2"/>`;
}
function cardTitle(x, y, w, text, mainFill = "#ffffff") {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  return `
    <text x="${x}" y="${y}" font-family="${font}" font-size="18" font-weight="bold" fill="${mainFill}">${escapeXml$8(text)}</text>
    <line x1="${x}" y1="${y + 8}" x2="${x + w}" y2="${y + 8}" stroke="rgba(255,255,255,0.2)" stroke-width="2"/>
  `;
}
function infoRow(x, y, w, label, value, highlight = false, mainFill = "#ffffff") {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const valAttr = highlight ? ' filter="url(#titleGlow)" font-weight="bold"' : ' font-weight="600"';
  return `
    <text x="${x}" y="${y}" font-family="${font}" font-size="13" fill="rgba(255,255,255,0.78)">${escapeXml$8(label)}</text>
    <text x="${x + w}" y="${y}" text-anchor="end" font-family="${font}" font-size="13" fill="${mainFill}"${valAttr}>${escapeXml$8(value)}</text>
    <line x1="${x}" y1="${y + 6}" x2="${x + w}" y2="${y + 6}" stroke="rgba(255,255,255,0.1)" stroke-width="1"/>
  `;
}
function buildStatusOverlaySvg(width, height, opts, customText) {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const mainFill = resolveSharpTextFill(customText, "#ffffff");
  const pad = 20;
  const name = escapeXml$8(truncateText$6(opts.name || "Bot", 18));
  const qq = escapeXml$8(String(opts.qq || ""));
  const cpuPct = toPercentNum(opts.cpuUsagePercent);
  const memPct = toPercentNum(opts.memoryUsagePercent);
  const diskPct = toPercentNum(opts.diskUsagePercent);
  const cpuColor = usageColor(cpuPct);
  const memColor = usageColor(memPct);
  const diskColor = usageColor(diskPct);
  const processes = (opts.processes || []).slice(0, 12);
  const headerX = pad;
  const headerY = pad;
  const headerW = width - pad * 2;
  const headerH = 150;
  const leftX = pad;
  const leftW = Math.floor((width - pad * 3) / 2);
  const rightX = leftX + leftW + pad;
  const rightW = width - rightX - pad;
  const mainY = headerY + headerH + 20;
  const sysH = 400;
  const storeY = mainY + sysH + 20;
  const storeH = height - storeY - pad;
  const rightH = height - mainY - pad;
  const infoCards = [
    escapeXml$8(String(opts.type || "")),
    escapeXml$8(String(opts.arch || "")),
    `群聊数量: ${opts.groupCount ?? 0}`,
    `好友数量: ${opts.friendCount ?? 0}`
  ];
  const cardW = 240;
  const cardH = 52;
  const cardsOriginX = headerX + headerW - cardW * 2 - 15;
  const cardsOriginY = headerY + 22;
  const parts = [];
  parts.push(`<defs>
    <filter id="titleGlow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="0" stdDeviation="2" flood-color="#ffffff" flood-opacity="0.9"/>
      <feDropShadow dx="0" dy="2" stdDeviation="6" flood-color="#ff77b7" flood-opacity="0.65"/>
    </filter>
    <filter id="pctGlowGreen" x="-40%" y="-40%" width="180%" height="180%">
      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#81C784" flood-opacity="0.7"/>
      <feDropShadow dx="0" dy="0" stdDeviation="6" flood-color="#4CAF50" flood-opacity="0.9"/>
    </filter>
    <filter id="pctGlowOrange" x="-40%" y="-40%" width="180%" height="180%">
      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#ffe082" flood-opacity="0.7"/>
      <feDropShadow dx="0" dy="0" stdDeviation="6" flood-color="#FF9800" flood-opacity="0.9"/>
    </filter>
    <filter id="pctGlowRed" x="-40%" y="-40%" width="180%" height="180%">
      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#ef9a9a" flood-opacity="0.7"/>
      <feDropShadow dx="0" dy="0" stdDeviation="6" flood-color="#F44336" flood-opacity="0.9"/>
    </filter>
  </defs>`);
  parts.push(glassRect$2(headerX, headerY, headerW, headerH));
  const avatarCx = headerX + 80;
  const avatarCy = headerY + 75;
  const avatarR = 60;
  parts.push(
    `<circle cx="${avatarCx}" cy="${avatarCy}" r="${avatarR}" fill="rgba(255,255,255,0.2)" stroke="rgba(255,255,255,0.35)" stroke-width="3"/>`
  );
  const infoX = headerX + 170;
  parts.push(
    `<text x="${infoX}" y="${headerY + 58}" font-family="${font}" font-size="32" font-weight="bold" fill="${mainFill}" filter="url(#titleGlow)">${name}</text>`
  );
  parts.push(
    `<text x="${infoX}" y="${headerY + 88}" font-family="${font}" font-size="16" fill="rgba(255,255,255,0.82)">QQ: ${qq}</text>`
  );
  infoCards.forEach((val, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = cardsOriginX + col * (cardW + 15);
    const y = cardsOriginY + row * (cardH + 12);
    parts.push(glassRect$2(x, y, cardW, cardH, 10));
    parts.push(
      `<text x="${x + cardW / 2}" y="${y + 32}" text-anchor="middle" font-family="${font}" font-size="15" font-weight="bold" fill="${mainFill}">${val}</text>`
    );
  });
  parts.push(glassRect$2(leftX, mainY, leftW, sysH));
  parts.push(cardTitle(leftX + 25, mainY + 32, leftW - 50, "系统状态", mainFill));
  const gaugeY = mainY + 175;
  const gaugeR = 58;
  parts.push(gaugeSvg(leftX + leftW * 0.28, gaugeY, gaugeR, cpuPct, cpuColor, usageGlowId(cpuPct), "CPU"));
  parts.push(gaugeSvg(leftX + leftW * 0.72, gaugeY, gaugeR, memPct, memColor, usageGlowId(memPct), "内存"));
  const rowX = leftX + 25;
  const rowW = leftW - 50;
  let rowY = mainY + 280;
  const rowGap = 34;
  parts.push(infoRow(rowX, rowY, rowW, "CPU核心数:", String(opts.cpuCount ?? 0), false, mainFill));
  rowY += rowGap;
  parts.push(infoRow(rowX, rowY, rowW, "CPU使用率:", `${cpuPct.toFixed(2)}%`, true, mainFill));
  rowY += rowGap;
  parts.push(infoRow(rowX, rowY, rowW, "内存总量:", String(opts.totalMemoryGB || ""), false, mainFill));
  rowY += rowGap;
  parts.push(infoRow(rowX, rowY, rowW, "内存使用率:", `${memPct.toFixed(2)}%`, true, mainFill));
  parts.push(glassRect$2(leftX, storeY, leftW, storeH));
  parts.push(cardTitle(leftX + 25, storeY + 32, leftW - 50, "存储状态", mainFill));
  const barX = leftX + 25;
  const barW = leftW - 50;
  const barY = storeY + 70;
  const barH = 20;
  const fillW = Math.max(0, Math.min(barW, barW * diskPct / 100));
  parts.push(
    `<text x="${barX}" y="${barY - 8}" font-family="${font}" font-size="12" fill="rgba(255,255,255,0.8)">磁盘使用情况</text>`
  );
  parts.push(
    `<text x="${barX + barW}" y="${barY - 8}" text-anchor="end" font-family="${font}" font-size="12" fill="rgba(255,255,255,0.8)">${escapeXml$8(String(opts.diskUsedGB || ""))} / ${escapeXml$8(String(opts.diskTotalGB || ""))}</text>`
  );
  parts.push(`<rect x="${barX}" y="${barY}" width="${barW}" height="${barH}" rx="10" fill="rgba(255,255,255,0.2)"/>`);
  parts.push(`<rect x="${barX}" y="${barY}" width="${fillW}" height="${barH}" rx="10" fill="${diskColor}"/>`);
  parts.push(
    `<text x="${barX}" y="${barY + 48}" font-family="${font}" font-size="16" font-weight="bold" fill="${mainFill}" filter="url(#${usageGlowId(diskPct)})">${diskPct.toFixed(2)}%</text>`
  );
  rowY = storeY + 150;
  parts.push(infoRow(rowX, rowY, rowW, "总容量:", String(opts.diskTotalGB || ""), false, mainFill));
  rowY += rowGap;
  parts.push(infoRow(rowX, rowY, rowW, "已用:", String(opts.diskUsedGB || ""), true, mainFill));
  rowY += rowGap;
  parts.push(infoRow(rowX, rowY, rowW, "可用:", String(opts.diskFreeGB || ""), false, mainFill));
  parts.push(glassRect$2(rightX, mainY, rightW, rightH));
  parts.push(cardTitle(rightX + 25, mainY + 32, rightW - 50, "进程占用排行榜 (按内存占用降序排列)", mainFill));
  const tableX = rightX + 20;
  const tableY = mainY + 58;
  const tableW = rightW - 40;
  const colRank = 36;
  const colPid = 70;
  const colMem = 100;
  const colCpu = 72;
  const colName = tableW - colRank - colPid - colMem - colCpu;
  parts.push(`<rect x="${tableX}" y="${tableY}" width="${tableW}" height="38" rx="8" fill="rgba(255,255,255,0.1)"/>`);
  const thY = tableY + 25;
  parts.push(`<text x="${tableX + 8}" y="${thY}" font-family="${font}" font-size="12" font-weight="600" fill="${mainFill}">排名</text>`);
  parts.push(`<text x="${tableX + colRank + 4}" y="${thY}" font-family="${font}" font-size="12" font-weight="600" fill="${mainFill}">进程名</text>`);
  parts.push(`<text x="${tableX + colRank + colName + 4}" y="${thY}" font-family="${font}" font-size="12" font-weight="600" fill="${mainFill}">PID</text>`);
  parts.push(`<text x="${tableX + colRank + colName + colPid + 4}" y="${thY}" font-family="${font}" font-size="12" font-weight="600" fill="${mainFill}">内存占用</text>`);
  parts.push(`<text x="${tableX + tableW - 8}" y="${thY}" text-anchor="end" font-family="${font}" font-size="12" font-weight="600" fill="${mainFill}">CPU占比</text>`);
  const rowH = 36;
  processes.forEach((proc, idx) => {
    const y = tableY + 38 + idx * rowH;
    const rank = idx + 1;
    const pName = escapeXml$8(truncateText$6(proc.name || "Unknown", 22));
    const pid = escapeXml$8(String(proc.pid || ""));
    const mem = escapeXml$8(`${proc.memoryMB || "0"} MB`);
    const cpu = escapeXml$8(`${proc.cpuPercent || "0"}%`);
    if (idx % 2 === 1) {
      parts.push(`<rect x="${tableX}" y="${y}" width="${tableW}" height="${rowH}" fill="rgba(255,255,255,0.04)"/>`);
    }
    const ty = y + 24;
    parts.push(`<text x="${tableX + 8}" y="${ty}" font-family="${font}" font-size="12" font-weight="bold" fill="#4CAF50">${rank}</text>`);
    parts.push(`<text x="${tableX + colRank + 4}" y="${ty}" font-family="${font}" font-size="12" fill="${mainFill}">${pName}</text>`);
    parts.push(`<text x="${tableX + colRank + colName + 4}" y="${ty}" font-family="${font}" font-size="12" fill="rgba(255,255,255,0.9)">${pid}</text>`);
    parts.push(`<text x="${tableX + colRank + colName + colPid + 4}" y="${ty}" font-family="${font}" font-size="12" fill="rgba(255,255,255,0.9)">${mem}</text>`);
    parts.push(`<text x="${tableX + tableW - 8}" y="${ty}" text-anchor="end" font-family="${font}" font-size="12" fill="rgba(255,255,255,0.9)">${cpu}</text>`);
    parts.push(`<line x1="${tableX}" y1="${y + rowH}" x2="${tableX + tableW}" y2="${y + rowH}" stroke="rgba(255,255,255,0.08)" stroke-width="1"/>`);
  });
  if (!processes.length) {
    parts.push(
      `<text x="${tableX + tableW / 2}" y="${tableY + 100}" text-anchor="middle" font-family="${font}" font-size="14" fill="rgba(255,255,255,0.6)">暂无进程数据</text>`
    );
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${parts.join("\n")}</svg>`;
}
async function roundAvatar$3(sharp, buf, size) {
  try {
    const mask = Buffer.from(
      `<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="white"/></svg>`
    );
    return sharp(buf).resize(size, size, { fit: "cover" }).ensureAlpha().composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
  } catch {
    return null;
  }
}
async function fitCompositeLayer$3(sharp, input, width, height) {
  return sharp(input).resize(width, height, { fit: "fill" }).ensureAlpha().png().toBuffer();
}
async function renderStatusWithSharpImpl(options, logger) {
  const width = options.width ?? 1400;
  const height = options.height ?? 900;
  const pluginDir = String(options.pluginDir || "").trim();
  const pluginPath = String(options.pluginPath || "").trim();
  const dataPath = String(options.dataPath || "").trim();
  const bgLocalPath = String(options.bgLocalPath || "").trim();
  try {
    const sharp = await loadSharp();
    const bgBuf = await loadStatusBackground(
      String(options.backgroundImageUrl || ""),
      bgLocalPath,
      pluginDir,
      pluginPath,
      dataPath
    );
    const composites = [];
    if (bgBuf && bgBuf.length > 0) {
      await applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath);
    } else {
      const fallback = await sharp({
        create: {
          width,
          height,
          channels: 3,
          background: { r: 102, g: 126, b: 234 }
        }
      }).png().toBuffer();
      composites.push({ input: fallback, top: 0, left: 0 });
      logger?.warn?.("[Sharp渲染] 运行状态背景图不可用，已使用默认底色");
    }
    const customText = loadSharpTextColorFromDataPath(dataPath);
    const overlaySvg = buildStatusOverlaySvg(width, height, options, customText);
    const overlayLayer = await fitCompositeLayer$3(sharp, Buffer.from(overlaySvg), width, height);
    composites.push({ input: overlayLayer, top: 0, left: 0 });
    const avatarSize = 120;
    const avatarUrl = `https://q4.qlogo.cn/g?b=qq&nk=${options.qq || ""}&s=5`;
    try {
      const avatarBuf = await fetchUrlBuffer$3(avatarUrl, 1e4);
      if (avatarBuf.length > 0) {
        const rounded = await roundAvatar$3(sharp, avatarBuf, avatarSize);
        if (rounded) {
          composites.push({ input: rounded, top: 40, left: 40 });
        }
      }
    } catch (_e) {
    }
    const out = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 0, g: 0, b: 0, alpha: 1 }
      }
    }).composite(composites).png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

function escapeXml$7(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function truncateText$5(text, maxLen) {
  const s = String(text || "").trim();
  if (s.length <= maxLen) return s;
  return `${s.slice(0, maxLen - 1)}…`;
}
function fetchUrlBuffer$2(url, timeoutMs = 12e3) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https") ? https : http;
    const req = lib.get(
      url,
      { timeout: timeoutMs, headers: { "User-Agent": "MKbot-SignInSharp/1.0" } },
      (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          fetchUrlBuffer$2(res.headers.location, timeoutMs).then(resolve).catch(reject);
          return;
        }
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode}`));
          res.resume();
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
        res.on("end", () => resolve(Buffer.concat(chunks)));
        res.on("error", reject);
      }
    );
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("timeout")));
  });
}
function buildSignInSvg(width, height, opts) {
  const isDay = opts.theme === "day";
  const padX = 20;
  const padTop = 40;
  const radius = 36;
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const nameColor = isDay ? "#ff5722" : "#60a5fa";
  const qqColor = isDay ? "#ff9800" : "#93c5fd";
  const statsCardBg = isDay ? "rgba(255,255,255,0.4)" : "rgba(30,41,59,0.4)";
  const statsLabel = isDay ? "#ff9800" : "#93c5fd";
  const dividerColor = isDay ? "rgba(255,152,0,0.15)" : "rgba(59,130,246,0.15)";
  const parts = [];
  parts.push(`<defs>
    <clipPath id="cardClip"><rect x="0" y="0" width="${width}" height="${height}" rx="${radius}" ry="${radius}"/></clipPath>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      ${isDay ? '<stop offset="0%" stop-color="#ffe0b2"/><stop offset="100%" stop-color="#b3e5fc"/>' : '<stop offset="0%" stop-color="#0f172a"/><stop offset="50%" stop-color="#1e293b"/><stop offset="100%" stop-color="#0f172a"/>'}
    </linearGradient>
    <linearGradient id="rankGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      ${isDay ? '<stop offset="0%" stop-color="#ff9800"/><stop offset="100%" stop-color="#ff5722"/>' : '<stop offset="0%" stop-color="#f59e0b"/><stop offset="100%" stop-color="#ea580c"/>'}
    </linearGradient>
    <linearGradient id="statGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      ${isDay ? '<stop offset="0%" stop-color="#ff9800"/><stop offset="100%" stop-color="#ff5722"/>' : '<stop offset="0%" stop-color="#f59e0b"/><stop offset="100%" stop-color="#ea580c"/>'}
    </linearGradient>
    <linearGradient id="signedGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      ${isDay ? '<stop offset="0%" stop-color="#ff9800"/><stop offset="100%" stop-color="#ff5722"/>' : '<stop offset="0%" stop-color="#f59e0b"/><stop offset="50%" stop-color="#3b82f6"/><stop offset="100%" stop-color="#06b6d4"/>'}
    </linearGradient>
    <linearGradient id="guiGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      ${isDay ? '<stop offset="0%" stop-color="#ff9800"/><stop offset="100%" stop-color="#ff5722"/>' : '<stop offset="0%" stop-color="#f59e0b"/><stop offset="100%" stop-color="#ea580c"/>'}
    </linearGradient>
    <linearGradient id="yuGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      ${isDay ? '<stop offset="0%" stop-color="#00e5ff"/><stop offset="100%" stop-color="#80deea"/>' : '<stop offset="0%" stop-color="#3b82f6"/><stop offset="100%" stop-color="#06b6d4"/>'}
    </linearGradient>
    <linearGradient id="avatarBorder" x1="0%" y1="0%" x2="100%" y2="100%">
      ${isDay ? '<stop offset="0%" stop-color="#ff5722"/><stop offset="50%" stop-color="#ff9800"/><stop offset="100%" stop-color="#48cae4"/>' : '<stop offset="0%" stop-color="#f59e0b"/><stop offset="50%" stop-color="#3b82f6"/><stop offset="100%" stop-color="#06b6d4"/>'}
    </linearGradient>
    <filter id="blobBlur" x="-50%" y="-50%" width="200%" height="200%">
      <feGaussianBlur stdDeviation="35"/>
    </filter>
  </defs>`);
  parts.push(`<g clip-path="url(#cardClip)">`);
  parts.push(`<rect x="0" y="0" width="${width}" height="${height}" fill="url(#bgGrad)"/>`);
  if (isDay) {
    parts.push(`<circle cx="620" cy="40" r="160" fill="#ffcc80" opacity="0.55" filter="url(#blobBlur)"/>`);
    parts.push(`<circle cx="60" cy="420" r="140" fill="#90e0ef" opacity="0.5" filter="url(#blobBlur)"/>`);
    parts.push(`<circle cx="180" cy="260" r="110" fill="#b3e5fc" opacity="0.45" filter="url(#blobBlur)"/>`);
  } else {
    parts.push(`<circle cx="620" cy="40" r="160" fill="#3b82f6" opacity="0.45" filter="url(#blobBlur)"/>`);
    parts.push(`<circle cx="60" cy="420" r="140" fill="#f59e0b" opacity="0.4" filter="url(#blobBlur)"/>`);
    parts.push(`<circle cx="180" cy="260" r="110" fill="#06b6d4" opacity="0.35" filter="url(#blobBlur)"/>`);
  }
  const avatarX = padX;
  const avatarY = padTop - 8;
  const avatarSize = 72;
  parts.push(
    `<rect x="${avatarX}" y="${avatarY}" width="${avatarSize}" height="${avatarSize}" rx="20" ry="20" fill="url(#avatarBorder)"/>`
  );
  parts.push(
    `<rect x="${avatarX + 3}" y="${avatarY + 3}" width="${avatarSize - 6}" height="${avatarSize - 6}" rx="17" ry="17" fill="#ffffff"/>`
  );
  const textX = avatarX + avatarSize + 12;
  parts.push(
    `<text x="${textX}" y="${avatarY + 30}" font-family="${font}" font-size="26" font-weight="700" fill="${nameColor}">${escapeXml$7(truncateText$5(opts.userName, 12))}</text>`
  );
  parts.push(
    `<text x="${textX}" y="${avatarY + 52}" font-family="${font}" font-size="15" fill="${qqColor}">QQ: ${escapeXml$7(String(opts.userId))}</text>`
  );
  parts.push(
    `<text x="${width - padX}" y="${avatarY + 52}" text-anchor="end" font-family="${font}" font-size="50" font-weight="800" fill="url(#rankGrad)">${escapeXml$7(opts.rankText)}</text>`
  );
  const centerY = 250;
  if (opts.signed) {
    parts.push(
      `<text x="${width / 2}" y="${centerY}" text-anchor="middle" font-family="${font}" font-size="72" font-weight="900" fill="url(#signedGrad)" letter-spacing="8">已签到</text>`
    );
  } else {
    const gj = Number(opts.guiJian ?? 0);
    const ye = Number(opts.yuEr ?? 0);
    const gjText = `+${gj}`;
    const yeText = `+${ye}`;
    const labelSize = 34;
    const valueSize = 68;
    const labelBaseline = 218;
    const valueBaseline = labelBaseline + 86;
    const leftColX = width * 0.27;
    const rightColX = width * 0.73;
    parts.push(
      `<text x="${leftColX}" y="${labelBaseline}" text-anchor="middle" font-family="${font}" font-size="${labelSize}" font-weight="700" fill="${nameColor}">归笺</text>`
    );
    parts.push(
      `<text x="${leftColX}" y="${valueBaseline}" text-anchor="middle" font-family="${font}" font-size="${valueSize}" font-weight="900" fill="url(#guiGrad)">${escapeXml$7(gjText)}</text>`
    );
    parts.push(
      `<text x="${rightColX}" y="${labelBaseline}" text-anchor="middle" font-family="${font}" font-size="${labelSize}" font-weight="700" fill="${isDay ? "#ff5722" : "#93c5fd"}">诱饵</text>`
    );
    parts.push(
      `<text x="${rightColX}" y="${valueBaseline}" text-anchor="middle" font-family="${font}" font-size="${valueSize}" font-weight="900" fill="url(#yuGrad)">${escapeXml$7(yeText)}</text>`
    );
  }
  const cardY = height - 30 - 148;
  const cardW = width - padX * 2;
  const cardH = 148;
  parts.push(
    `<rect x="${padX}" y="${cardY}" width="${cardW}" height="${cardH}" rx="28" ry="28" fill="${statsCardBg}" stroke="rgba(255,255,255,0.2)" stroke-width="1"/>`
  );
  const col1 = padX + cardW * 0.25;
  const col2 = padX + cardW * 0.75;
  parts.push(
    `<text x="${col1}" y="${cardY + 36}" text-anchor="middle" font-family="${font}" font-size="16" font-weight="600" fill="${statsLabel}">累计天数</text>`
  );
  parts.push(
    `<text x="${col1}" y="${cardY + 72}" text-anchor="middle" font-family="${font}" font-size="32" font-weight="900" fill="url(#statGrad)">${escapeXml$7(opts.totalDays)}</text>`
  );
  parts.push(
    `<text x="${col2}" y="${cardY + 36}" text-anchor="middle" font-family="${font}" font-size="16" font-weight="600" fill="${statsLabel}">连签次数</text>`
  );
  parts.push(
    `<text x="${col2}" y="${cardY + 72}" text-anchor="middle" font-family="${font}" font-size="28" font-weight="900" fill="url(#statGrad)">${escapeXml$7(truncateText$5(opts.streakText, 14))}</text>`
  );
  const dividerY = cardY + 92;
  parts.push(
    `<rect x="${padX + 24}" y="${dividerY}" width="${cardW - 48}" height="1" fill="${dividerColor}"/>`
  );
  const events = Array.isArray(opts.events) ? opts.events.filter((e) => String(e?.text || "").trim()) : [];
  if (events.length > 0) {
    let tagX = padX + 28;
    const tagY = cardY + 112;
    const maxX = padX + cardW - 20;
    for (const ev of events.slice(0, 4)) {
      const text = truncateText$5(ev.text, 18);
      const tagW = Math.min(220, text.length * 14 + 28);
      if (tagX + tagW > maxX) break;
      const fill = ev.bonus ? isDay ? "url(#rankGrad)" : "url(#signedGrad)" : isDay ? "rgba(255,152,0,0.15)" : "rgba(59,130,246,0.15)";
      const stroke = ev.bonus ? "none" : isDay ? "rgba(255,152,0,0.3)" : "rgba(59,130,246,0.3)";
      const textFill = ev.bonus ? "#ffffff" : isDay ? "#ff9800" : "#60a5fa";
      parts.push(
        `<rect x="${tagX}" y="${tagY}" width="${tagW}" height="28" rx="14" ry="14" fill="${fill}" stroke="${stroke}" stroke-width="1"/>`
      );
      parts.push(
        `<text x="${tagX + tagW / 2}" y="${tagY + 19}" text-anchor="middle" font-family="${font}" font-size="13" font-weight="600" fill="${textFill}">${escapeXml$7(text)}</text>`
      );
      tagX += tagW + 10;
    }
  }
  parts.push(`</g>`);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${parts.join("\n")}</svg>`;
}
async function roundAvatar$2(sharp, buf, size) {
  try {
    const mask = Buffer.from(
      `<svg width="${size}" height="${size}"><rect x="0" y="0" width="${size}" height="${size}" rx="16" ry="16" fill="white"/></svg>`
    );
    return sharp(buf).resize(size, size, { fit: "cover" }).ensureAlpha().composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
  } catch {
    return null;
  }
}
async function renderSignInWithSharpImpl(options, logger) {
  const width = options.width ?? 720;
  const height = options.height ?? 520;
  try {
    const sharp = await loadSharp();
    const svg = buildSignInSvg(width, height, options);
    const uiLayer = await sharp(Buffer.from(svg)).png().toBuffer();
    const composites = [
      { input: uiLayer, top: 0, left: 0 }
    ];
    const avatarUrl = String(options.avatarUrl || "").trim() || `https://q4.qlogo.cn/g?b=qq&nk=${options.userId}&s=5`;
    try {
      const avatarBuf = await fetchUrlBuffer$2(avatarUrl, 1e4);
      if (avatarBuf.length > 0) {
        const rounded = await roundAvatar$2(sharp, avatarBuf, 66);
        if (rounded) {
          composites.push({ input: rounded, top: 32, left: 23 });
        }
      }
    } catch (_e) {
    }
    const out = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 0, g: 0, b: 0, alpha: 0 }
      }
    }).composite(composites).png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

function escapeXml$6(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function truncateText$4(text, maxLen) {
  const s = String(text).trim();
  if (s.length <= maxLen) return s;
  return `${s.slice(0, maxLen - 1)}…`;
}
function valueFontSize(text, base = 34, min = 20) {
  const len = String(text || "").length;
  if (len <= 8) return base;
  if (len <= 12) return 28;
  if (len <= 18) return 24;
  return min;
}
function fetchUrlBuffer$1(url, timeoutMs = 12e3) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https") ? https : http;
    const req = lib.get(
      url,
      { timeout: timeoutMs, headers: { "User-Agent": "MKbot-WalletSharp/1.0" } },
      (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          fetchUrlBuffer$1(res.headers.location, timeoutMs).then(resolve).catch(reject);
          return;
        }
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode}`));
          res.resume();
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
        res.on("end", () => resolve(Buffer.concat(chunks)));
        res.on("error", reject);
      }
    );
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("timeout")));
  });
}
function glassRect$1(x, y, w, h, r = 18) {
  return [
    `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" ry="${r}" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.28)" stroke-width="1.5"/>`,
    `<rect x="${x + 1}" y="${y + 1}" width="${w - 2}" height="${Math.max(10, Math.floor(h * 0.22))}" rx="${Math.max(8, r - 4)}" ry="${Math.max(8, r - 4)}" fill="rgba(255,255,255,0.08)"/>`
  ].join("\n");
}
async function loadWalletBackground(bgLocalPath, pluginDir, dataPath) {
  const candidates = [];
  const push = (v) => {
    const s = String(v || "").trim();
    if (s && !candidates.includes(s)) candidates.push(s);
  };
  push(bgLocalPath);
  const localNames = ["运行状态.jpg", "运行状态.jpeg", "运行状态.png", "运行状态.webp"];
  const roots = [
    path.join(String(pluginDir || "").trim(), "默认资源", "image"),
    path.join(String(dataPath || "").trim(), "默认资源", "image")
  ];
  try {
    const here = path.dirname(fileURLToPath(import.meta.url));
    roots.push(path.join(here, "默认资源", "image"));
    roots.push(path.join(here, "..", "默认资源", "image"));
  } catch {
  }
  for (const root of roots) {
    if (!String(root || "").trim()) continue;
    for (const name of localNames) {
      push(path.join(root, name));
    }
  }
  for (const src of candidates) {
    try {
      if (/^https?:\/\//i.test(src)) {
        const buf = await fetchUrlBuffer$1(src, 2e4);
        if (buf?.length) return buf;
        continue;
      }
      if (fs.existsSync(src) && fs.statSync(src).isFile()) {
        return fs.readFileSync(src);
      }
    } catch {
    }
  }
  return null;
}
function buildWalletSvg(width, height, opts, customText) {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const mainFill = resolveSharpTextFill(customText, "#ffffff");
  const pad = 28;
  const cardX = pad;
  const cardY = pad;
  const cardW = width - pad * 2;
  const cardH = height - pad * 2;
  const title = escapeXml$6(opts.title || "我的信息");
  const userName = escapeXml$6(truncateText$4(opts.userName || "旅人", 14));
  const userId = escapeXml$6(String(opts.userId || ""));
  const time = escapeXml$6(opts.time || "");
  const currentMoney = escapeXml$6(opts.currentMoney || "0归笺");
  const bankMoney = escapeXml$6(opts.bankMoney || "0归笺");
  const baitCount = escapeXml$6(String(opts.baitCount ?? "0"));
  const muteCardCount = escapeXml$6(String(opts.muteCardCount ?? "0"));
  const signTotal = escapeXml$6(String(opts.signTotal ?? "0"));
  const signStreak = escapeXml$6(String(opts.signStreak ?? "0"));
  const parts = [];
  parts.push(`<defs>
    <linearGradient id="valGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#c8e7ff"/>
    </linearGradient>
    <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#e8f4ff"/>
      <stop offset="100%" stop-color="#9ec9e8"/>
    </linearGradient>
    <filter id="titleGlow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="0" stdDeviation="2" flood-color="#ffffff" flood-opacity="0.85"/>
      <feDropShadow dx="0" dy="1" stdDeviation="4" flood-color="#8eb8d8" flood-opacity="0.35"/>
    </filter>
    <filter id="valGlow" x="-35%" y="-35%" width="170%" height="170%">
      <feDropShadow dx="0" dy="0" stdDeviation="2" flood-color="#ffffff" flood-opacity="0.55"/>
      <feDropShadow dx="0" dy="1" stdDeviation="5" flood-color="#9ec9e8" flood-opacity="0.35"/>
    </filter>
  </defs>`);
  parts.push(glassRect$1(cardX, cardY, cardW, cardH, 26));
  const avatarX = cardX + 22;
  const avatarY = cardY + 22;
  const avatarSize = 86;
  parts.push(
    `<circle cx="${avatarX + avatarSize / 2}" cy="${avatarY + avatarSize / 2}" r="${avatarSize / 2 + 1.5}" fill="rgba(255,255,255,0.14)" stroke="rgba(255,255,255,0.45)" stroke-width="2.5"/>`
  );
  const infoX = avatarX + avatarSize + 18;
  parts.push(
    `<text x="${infoX}" y="${avatarY + 26}" font-family="${font}" font-size="13" font-weight="700" fill="rgba(255,255,255,0.72)" letter-spacing="1">time:${time}</text>`
  );
  parts.push(
    `<text x="${infoX}" y="${avatarY + 58}" font-family="${font}" font-size="30" font-weight="900" fill="${mainFill}" filter="url(#titleGlow)">${title}</text>`
  );
  parts.push(
    `<text x="${infoX}" y="${avatarY + 82}" font-family="${font}" font-size="15" fill="rgba(255,255,255,0.82)">${userName} (${userId})</text>`
  );
  const tileY = cardY + 118;
  const gap = 14;
  const tileW = (cardW - 44 - gap) / 2;
  const tileH = 112;
  const tileX0 = cardX + 22;
  const tiles = [
    { label: "现有货币", value: currentMoney },
    { label: "银行储存", value: bankMoney },
    { label: "诱饵数量", value: baitCount, unit: "个" },
    { label: "禁言卡", value: muteCardCount, unit: "张" }
  ];
  tiles.forEach((tile, i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = tileX0 + col * (tileW + gap);
    const y = tileY + row * (tileH + gap);
    const displayValue = tile.unit ? `${tile.value}${tile.unit}` : tile.value;
    const valSize = valueFontSize(displayValue, 30, 18);
    parts.push(glassRect$1(x, y, tileW, tileH, 18));
    parts.push(
      `<circle cx="${x + 22}" cy="${y + 24}" r="4.5" fill="rgba(200,231,255,0.9)"/>`
    );
    parts.push(
      `<text x="${x + 36}" y="${y + 28}" font-family="${font}" font-size="16" font-weight="800" fill="rgba(255,255,255,0.92)">${escapeXml$6(tile.label)}</text>`
    );
    parts.push(
      `<text x="${x + 22}" y="${y + 78}" font-family="${font}" font-size="${valSize}" font-weight="900" fill="url(#valGrad)" filter="url(#valGlow)">${escapeXml$6(displayValue)}</text>`
    );
  });
  const footY = tileY + tileH * 2 + gap + 14;
  const footW = (cardW - 44 - gap) / 2;
  const footH = 74;
  const footItems = [
    { label: "累计签到", value: signTotal, unit: "天" },
    { label: "连续签到", value: signStreak, unit: "天" }
  ];
  footItems.forEach((item, i) => {
    const x = tileX0 + i * (footW + gap);
    parts.push(glassRect$1(x, footY, footW, footH, 16));
    parts.push(
      `<text x="${x + 16}" y="${footY + 26}" font-family="${font}" font-size="13" font-weight="600" fill="rgba(255,255,255,0.78)">${escapeXml$6(item.label)}</text>`
    );
    parts.push(
      `<text x="${x + 16}" y="${footY + 54}" font-family="${font}" font-size="26" font-weight="900" fill="url(#accentGrad)" filter="url(#valGlow)">${escapeXml$6(item.value)}<tspan font-size="13" fill="rgba(255,255,255,0.7)" filter="none"> ${escapeXml$6(item.unit)}</tspan></text>`
    );
  });
  parts.push(
    `<text x="${cardX + cardW / 2}" y="${cardY + cardH - 14}" text-anchor="middle" font-family="${font}" font-size="11" fill="rgba(255,255,255,0.38)" letter-spacing="2">MK-Bot · 娱乐经济数据</text>`
  );
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${parts.join("\n")}</svg>`;
}
async function roundAvatar$1(sharp, buf, size) {
  try {
    const mask = Buffer.from(
      `<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="white"/></svg>`
    );
    return sharp(buf).resize(size, size, { fit: "cover" }).ensureAlpha().composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
  } catch {
    return null;
  }
}
async function fitCompositeLayer$2(sharp, input, width, height) {
  return sharp(input).resize(width, height, { fit: "fill" }).ensureAlpha().png().toBuffer();
}
async function renderWalletWithSharpImpl(options, logger) {
  const width = options.width ?? 1080;
  const height = options.height ?? 720;
  const pluginDir = String(options.pluginDir || "").trim();
  const dataPath = String(options.dataPath || "").trim();
  const bgLocalPath = String(options.bgLocalPath || "").trim();
  try {
    const sharp = await loadSharp();
    const composites = [];
    const bgBuf = await loadWalletBackground(bgLocalPath, pluginDir, dataPath);
    if (bgBuf && bgBuf.length > 0) {
      await applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath);
    } else {
      const fallback = await sharp({
        create: {
          width,
          height,
          channels: 4,
          background: { r: 22, g: 28, b: 38, alpha: 1 }
        }
      }).png().toBuffer();
      composites.push({ input: fallback, top: 0, left: 0 });
      logger?.warn?.("[Sharp渲染] 我的信息背景图不可用，已使用默认底色");
    }
    const customText = loadSharpTextColorFromDataPath(dataPath);
    const svg = buildWalletSvg(width, height, options, customText);
    const uiLayer = await fitCompositeLayer$2(sharp, Buffer.from(svg), width, height);
    composites.push({ input: uiLayer, top: 0, left: 0 });
    const avatarSize = 86;
    const avatarTop = 28 + 22;
    const avatarLeft = 28 + 22;
    const avatarUrl = `https://q4.qlogo.cn/g?b=qq&nk=${options.userId}&s=5`;
    try {
      const avatarBuf = await fetchUrlBuffer$1(avatarUrl, 1e4);
      if (avatarBuf.length > 0) {
        const rounded = await roundAvatar$1(sharp, avatarBuf, avatarSize);
        if (rounded) {
          composites.push({ input: rounded, top: avatarTop, left: avatarLeft });
        }
      }
    } catch (_e) {
    }
    const out = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 18, g: 22, b: 30, alpha: 1 }
      }
    }).composite(composites).png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

function escapeXml$5(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function truncateText$3(text, maxLen) {
  const s = String(text || "").trim();
  if (s.length <= maxLen) return s;
  return `${s.slice(0, maxLen - 1)}…`;
}
function buildShopSvg(width, height, opts) {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const pad = 40;
  const title = escapeXml$5(opts.title || "道具商店");
  const subtitle = escapeXml$5(opts.subtitle || "");
  const hint = escapeXml$5(opts.hint || "");
  const items = Array.isArray(opts.items) ? opts.items : [];
  const parts = [];
  parts.push(`<defs>
    <linearGradient id="shopBg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ff9a9e"/>
      <stop offset="42%" stop-color="#fad0c4"/>
      <stop offset="100%" stop-color="#a18cd1"/>
    </linearGradient>
    <linearGradient id="sheetGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="rgba(255,255,255,0.94)"/>
      <stop offset="100%" stop-color="rgba(255,255,255,0.82)"/>
    </linearGradient>
    <linearGradient id="priceGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#ff7043"/>
      <stop offset="100%" stop-color="#ec407a"/>
    </linearGradient>
    <linearGradient id="priceDownGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#43a047"/>
      <stop offset="100%" stop-color="#2e7d32"/>
    </linearGradient>
    <filter id="softBlob" x="-40%" y="-40%" width="180%" height="180%">
      <feGaussianBlur stdDeviation="42"/>
    </filter>
  </defs>`);
  parts.push(`<rect x="0" y="0" width="${width}" height="${height}" fill="url(#shopBg)"/>`);
  parts.push(`<circle cx="${width - 70}" cy="60" r="170" fill="#fff3e0" opacity="0.35" filter="url(#softBlob)"/>`);
  parts.push(`<circle cx="50" cy="${height - 30}" r="150" fill="#e1bee7" opacity="0.32" filter="url(#softBlob)"/>`);
  const sheetX = pad;
  const sheetY = pad;
  const sheetW = width - pad * 2;
  const sheetH = height - pad * 2 - (hint ? 12 : 0);
  parts.push(
    `<rect x="${sheetX}" y="${sheetY}" width="${sheetW}" height="${sheetH}" rx="28" ry="28" fill="url(#sheetGrad)" stroke="rgba(255,255,255,0.75)" stroke-width="2"/>`
  );
  parts.push(
    `<text x="${sheetX + 36}" y="${sheetY + 56}" font-family="${font}" font-size="40" font-weight="900" fill="#2d2430">${title}</text>`
  );
  if (subtitle) {
    parts.push(
      `<text x="${sheetX + 36}" y="${sheetY + 90}" font-family="${font}" font-size="18" fill="rgba(45,36,48,0.55)">${subtitle}</text>`
    );
  }
  const headY = sheetY + 126;
  parts.push(
    `<text x="${sheetX + 36}" y="${headY}" font-family="${font}" font-size="15" font-weight="700" fill="rgba(45,36,48,0.4)" letter-spacing="1">商品</text>`
  );
  parts.push(
    `<text x="${sheetX + sheetW * 0.46}" y="${headY}" font-family="${font}" font-size="15" font-weight="700" fill="rgba(45,36,48,0.4)" letter-spacing="1">限购</text>`
  );
  parts.push(
    `<text x="${sheetX + sheetW - 36}" y="${headY}" text-anchor="end" font-family="${font}" font-size="15" font-weight="700" fill="rgba(45,36,48,0.4)" letter-spacing="1">今日价</text>`
  );
  parts.push(
    `<line x1="${sheetX + 28}" y1="${headY + 14}" x2="${sheetX + sheetW - 28}" y2="${headY + 14}" stroke="rgba(45,36,48,0.08)" stroke-width="1.5"/>`
  );
  const rowH = 108;
  const rowStart = headY + 28;
  items.forEach((item, i) => {
    const y = rowStart + i * rowH;
    const soldOut = !!item.soldOut;
    const name = escapeXml$5(truncateText$3(item.name, 8));
    const modeLabel = escapeXml$5(truncateText$3(item.modeLabel, 6));
    const priceNum = String(item.price || "-").replace(/\s*归笺\s*/g, "").trim();
    const price = escapeXml$5(priceNum);
    const baseNum = String(item.basePrice || "").replace(/\s*归笺\s*/g, "").trim();
    escapeXml$5(baseNum);
    const trend = item.trend === "down" ? "down" : item.trend === "same" ? "same" : "up";
    const limitText = escapeXml$5(item.limitText || "-");
    const remainText = escapeXml$5(item.remainText || "-");
    if (i % 2 === 0) {
      parts.push(
        `<rect x="${sheetX + 18}" y="${y}" width="${sheetW - 36}" height="${rowH - 12}" rx="18" fill="rgba(255,107,138,0.06)"/>`
      );
    }
    parts.push(
      `<text x="${sheetX + 48}" y="${y + 46}" font-family="${font}" font-size="18" font-weight="800" fill="rgba(255,107,138,0.75)">${String(i + 1).padStart(2, "0")}</text>`
    );
    parts.push(
      `<text x="${sheetX + 84}" y="${y + 40}" font-family="${font}" font-size="28" font-weight="900" fill="#2d2430">${name}</text>`
    );
    const badgeW = Math.max(72, modeLabel.length * 16 + 28);
    parts.push(
      `<rect x="${sheetX + 84}" y="${y + 54}" width="${badgeW}" height="28" rx="14" fill="rgba(139,124,246,0.14)"/>`
    );
    parts.push(
      `<text x="${sheetX + 84 + badgeW / 2}" y="${y + 74}" text-anchor="middle" font-family="${font}" font-size="14" font-weight="700" fill="#6a5acd">${modeLabel}</text>`
    );
    parts.push(
      `<text x="${sheetX + sheetW * 0.46}" y="${y + 40}" font-family="${font}" font-size="17" fill="rgba(45,36,48,0.55)">${limitText}</text>`
    );
    parts.push(
      `<text x="${sheetX + sheetW * 0.46}" y="${y + 72}" font-family="${font}" font-size="22" font-weight="800" fill="${soldOut ? "#e53935" : "#43a047"}">${remainText}</text>`
    );
    const priceRight = sheetX + sheetW - 36;
    const priceColor = trend === "down" ? "url(#priceDownGrad)" : "url(#priceGrad)";
    if (trend === "down" && baseNum && baseNum !== priceNum) {
      const strike = escapeXml$5(baseNum);
      const strikeApproxW = baseNum.length * 12 + 4;
      const strikeX = priceRight - Math.max(120, priceNum.length * 18) - 16 - strikeApproxW;
      parts.push(
        `<text x="${strikeX}" y="${y + 48}" font-family="${font}" font-size="18" font-weight="600" fill="rgba(45,36,48,0.38)">${strike}</text>`
      );
      parts.push(
        `<line x1="${strikeX - 2}" y1="${y + 42}" x2="${strikeX + strikeApproxW}" y2="${y + 42}" stroke="rgba(45,36,48,0.45)" stroke-width="2"/>`
      );
      parts.push(
        `<text x="${priceRight}" y="${y + 50}" text-anchor="end" font-family="${font}" font-size="34" font-weight="900" fill="${priceColor}">${price}</text>`
      );
      parts.push(
        `<text x="${priceRight}" y="${y + 76}" text-anchor="end" font-family="${font}" font-size="14" fill="#43a047" font-weight="700">归笺 · 降价</text>`
      );
    } else {
      parts.push(
        `<text x="${priceRight}" y="${y + 50}" text-anchor="end" font-family="${font}" font-size="34" font-weight="900" fill="${priceColor}">${price}</text>`
      );
      if (trend === "up") {
        const arrowX = priceRight - Math.max(70, priceNum.length * 18) - 28;
        parts.push(
          `<path d="M ${arrowX} ${y + 54} L ${arrowX + 10} ${y + 38} L ${arrowX + 20} ${y + 54} Z" fill="#ec407a"/>`
        );
        parts.push(
          `<rect x="${arrowX + 7}" y="${y + 54}" width="6" height="12" rx="1" fill="#ec407a"/>`
        );
        parts.push(
          `<text x="${priceRight}" y="${y + 76}" text-anchor="end" font-family="${font}" font-size="14" fill="rgba(45,36,48,0.4)">归笺</text>`
        );
      } else {
        parts.push(
          `<text x="${priceRight}" y="${y + 76}" text-anchor="end" font-family="${font}" font-size="14" fill="rgba(45,36,48,0.4)">归笺</text>`
        );
      }
    }
  });
  if (hint) {
    parts.push(
      `<text x="${width / 2}" y="${height - 18}" text-anchor="middle" font-family="${font}" font-size="15" fill="rgba(255,255,255,0.88)">${hint}</text>`
    );
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${parts.join("\n")}</svg>`;
}
async function renderShopWithSharpImpl(options, logger) {
  const items = Array.isArray(options.items) ? options.items : [];
  const width = options.width ?? 1280;
  const headerBlock = 40 + 126 + 28;
  const rowBlock = Math.max(1, items.length) * 108;
  const height = Math.max(420, headerBlock + rowBlock + 64);
  try {
    const sharp = await loadSharp();
    const svg = buildShopSvg(width, height, options);
    const out = await sharp(Buffer.from(svg)).png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

const FISH_BASKET_PER_PAGE = 100;
const COLUMN_COUNT = 3;
function escapeXml$4(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function truncateText$2(text, maxLen) {
  const s = String(text || "").trim();
  if (s.length <= maxLen) return s;
  return `${s.slice(0, maxLen - 1)}…`;
}
function formatWeight(w) {
  const n = Number(w);
  if (!Number.isFinite(n)) return "0kg";
  const s = n.toFixed(3).replace(/\.?0+$/, "");
  return `${s}kg`;
}
async function loadFishBasketBackground(bgLocalPath, pluginDir, dataPath) {
  const candidates = [];
  const push = (v) => {
    const s = String(v || "").trim();
    if (s && !candidates.includes(s)) candidates.push(s);
  };
  push(bgLocalPath);
  const localNames = ["运势13.png", "运势13.jpg", "运势13.jpeg", "运势13.webp"];
  const roots = [
    path.join(String(pluginDir || "").trim(), "默认资源", "image"),
    path.join(String(dataPath || "").trim(), "默认资源", "image")
  ];
  for (const root of roots) {
    if (!String(root || "").trim()) continue;
    for (const name of localNames) {
      push(path.join(root, name));
    }
  }
  for (const src of candidates) {
    try {
      if (fs.existsSync(src) && fs.statSync(src).isFile()) {
        return fs.readFileSync(src);
      }
    } catch {
    }
  }
  return null;
}
async function fitCompositeLayer$1(sharp, input, width, height) {
  return sharp(input).resize(width, height, { fit: "fill" }).ensureAlpha().png().toBuffer();
}
function pickDensity(_recordCount) {
  return { width: 2100, rowH: 28, categoryH: 32, tierH: 36, colHeadH: 30, nameSize: 14, cellSize: 13, colGap: 18 };
}
function buildFishBasketRenderLines(items, rankOffset = 0) {
  const capped = items.slice(0, FISH_BASKET_PER_PAGE);
  const groupMap = /* @__PURE__ */ new Map();
  for (const item of capped) {
    const list = groupMap.get(item.name) || [];
    list.push(item);
    groupMap.set(item.name, list);
  }
  const groups = [...groupMap.entries()].map(([name, rows]) => {
    const sortedRows = [...rows].sort((a, b) => b.weight - a.weight || b.count - a.count);
    const subCount = sortedRows.reduce((s, r) => s + r.count, 0);
    const subTotal = sortedRows.reduce((s, r) => s + r.totalPrice, 0);
    return {
      name,
      tier: sortedRows.some((r) => r.tier === "premium") ? "premium" : "normal",
      maxWeight: Math.max(...sortedRows.map((r) => r.weight)),
      rows: sortedRows,
      subCount,
      subTotal
    };
  }).sort((a, b) => b.maxWeight - a.maxWeight || a.name.localeCompare(b.name, "zh-CN"));
  const lines = [];
  let lastTier = "";
  let rank = rankOffset;
  for (const g of groups) {
    if (g.tier !== lastTier) {
      lines.push({ type: "tier", tier: g.tier });
      lastTier = g.tier;
    }
    const rowEntries = [];
    for (const item of g.rows) {
      rank += 1;
      rowEntries.push({ item, rank });
    }
    lines.push({
      type: "category",
      name: g.name,
      tier: g.tier,
      subCount: g.subCount,
      subTotal: g.subTotal,
      rows: rowEntries
    });
  }
  return lines;
}
function estimateCategoryBlockHeight(cat, density) {
  return density.categoryH + cat.rows.length * density.rowH + 8;
}
function estimateCategoryStride(cat, density) {
  return estimateCategoryBlockHeight(cat, density) + 8;
}
function distributeCategoriesToColumns(categories, density) {
  const cols = Array.from({ length: COLUMN_COUNT }, () => []);
  const heights = new Array(COLUMN_COUNT).fill(0);
  for (const cat of categories) {
    const h = estimateCategoryStride(cat, density);
    let minIdx = 0;
    for (let i = 1; i < COLUMN_COUNT; i += 1) {
      if (heights[i] < heights[minIdx]) minIdx = i;
    }
    cols[minIdx].push(cat);
    heights[minIdx] += h;
  }
  return cols;
}
function rowHighlightKind(rank, tier) {
  if (rank === 1) return "rank1";
  if (rank === 2) return "rank2";
  if (rank === 3) return "rank3";
  return tier === "premium" ? "premium" : "normal";
}
function nameTextAttr(kind, size = 13) {
  const map = {
    rank1: { fill: "url(#rank1Grad)", filter: "url(#glowRank1)" },
    rank2: { fill: "url(#rank2Grad)", filter: "url(#glowRank2)" },
    rank3: { fill: "url(#rank3Grad)", filter: "url(#glowRank3)" },
    premium: { fill: "url(#premiumGrad)", filter: "url(#glowPremium)" },
    normal: { fill: "url(#normalGrad)", filter: "url(#glowNormal)" }
  };
  const s = map[kind] || { fill: "#ffffff", filter: "" };
  const filterAttr = s.filter ? ` filter="${s.filter}"` : "";
  return `font-size="${size}" font-weight="800" fill="${s.fill}"${filterAttr}`;
}
function renderCategoryBlock(cat, x, y, colW, density, font, mainFill) {
  const parts = [];
  const pad = 8;
  const innerW = colW - pad * 2;
  const tag = cat.tier === "premium" ? "珍" : "常";
  const tagColor = cat.tier === "premium" ? "#FFD54F" : "#80DEEA";
  const blockH = estimateCategoryBlockHeight(cat, density);
  const stride = estimateCategoryStride(cat, density);
  parts.push(
    `<rect x="${x}" y="${y}" width="${colW}" height="${blockH}" rx="10" fill="rgba(255,255,255,0.10)" stroke="rgba(255,255,255,0.28)" stroke-width="1"/>`
  );
  parts.push(
    `<rect x="${x}" y="${y}" width="4" height="${blockH}" rx="2" fill="${tagColor}" opacity="0.85"/>`
  );
  const headY = y + density.categoryH - 9;
  parts.push(
    `<text x="${x + pad + 4}" y="${headY}" font-family="${font}" font-size="${density.nameSize}" font-weight="900" fill="${mainFill}">${escapeXml$4(truncateText$2(cat.name, 8))} · ${tag} · ${cat.subCount}条 · ${cat.subTotal}</text>`
  );
  let rowY = y + density.categoryH;
  for (let i = 0; i < cat.rows.length; i += 1) {
    const { item, rank } = cat.rows[i];
    if (i % 2 === 0) {
      parts.push(
        `<rect x="${x + pad}" y="${rowY}" width="${innerW}" height="${density.rowH}" rx="4" fill="rgba(255,255,255,0.05)"/>`
      );
    }
    const ty = rowY + density.rowH - 7;
    const rankColor = rank <= 3 ? ["#FFD700", "#C0C0C0", "#CD7F32"][rank - 1] : "rgba(255,255,255,0.55)";
    const hl = rowHighlightKind(rank, item.tier);
    parts.push(
      `<text x="${x + pad + 4}" y="${ty}" font-family="${font}" font-size="${density.cellSize}" font-weight="700" fill="${rankColor}">#${rank}</text>`
    );
    parts.push(
      `<text x="${x + pad + 34}" y="${ty}" font-family="${font}" ${nameTextAttr(hl, density.cellSize + 1)}>${formatWeight(item.weight)}</text>`
    );
    parts.push(
      `<text x="${x + pad + 98}" y="${ty}" font-family="${font}" font-size="${density.cellSize}" font-weight="700" fill="${mainFill}">×${item.count}</text>`
    );
    parts.push(
      `<text x="${x + colW - pad - 4}" y="${ty}" text-anchor="end" font-family="${font}" font-size="${density.cellSize}" font-weight="700" fill="rgba(255,255,255,0.92)">${item.totalPrice}</text>`
    );
    rowY += density.rowH;
  }
  return { parts, height: stride };
}
function renderColumnCategories(categories, x, startY, colW, density, font, mainFill) {
  const parts = [];
  let y = startY;
  for (const cat of categories) {
    const block = renderCategoryBlock(cat, x, y, colW, density, font, mainFill);
    parts.push(...block.parts);
    y += block.height;
  }
  return { parts, height: y - startY };
}
function calcFishBasketCanvasHeight(lines, density) {
  const pad = 24;
  const headerH = 188;
  const footerH = 56;
  const safety = 32;
  let bodyH = 0;
  let tierCats = [];
  const flushTier = () => {
    if (!tierCats.length) return;
    bodyH += density.tierH + 8;
    const cols = distributeCategoriesToColumns(tierCats, density);
    const colHeights = cols.map(
      (cats) => cats.reduce((s, c) => s + estimateCategoryStride(c, density), 0)
    );
    bodyH += Math.max(...colHeights, 0) + 12;
    tierCats = [];
  };
  for (const line of lines) {
    if (line.type === "tier") {
      flushTier();
    } else if (line.type === "category") {
      tierCats.push(line);
    }
  }
  flushTier();
  return pad * 2 + headerH + bodyH + footerH + safety;
}
function buildFishBasketSvg(width, height, opts, lines, density, customText) {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const mainFill = resolveSharpTextFill(customText, "#ffffff");
  const pad = 24;
  const headerH = 188;
  const cardX = pad;
  const cardY = pad;
  const cardW = width - pad * 2;
  const cardH = height - pad * 2;
  const innerX = cardX + 20;
  const contentW = cardW - 40;
  const userName = escapeXml$4(truncateText$2(opts.userName || "旅人", 14));
  const userId = escapeXml$4(String(opts.userId || ""));
  const time = escapeXml$4(opts.time || "");
  const totalValue = escapeXml$4(String(opts.totalValue || "0归笺"));
  const colW = Math.floor((contentW - density.colGap * (COLUMN_COUNT - 1)) / COLUMN_COUNT);
  const parts = [];
  parts.push(`<defs>

    <linearGradient id="rank1Grad" x1="0%" y1="0%" x2="100%" y2="0%">

      <stop offset="0%" stop-color="#ffe082"/><stop offset="100%" stop-color="#ff6f00"/>

    </linearGradient>

    <linearGradient id="rank2Grad" x1="0%" y1="0%" x2="100%" y2="0%">

      <stop offset="0%" stop-color="#f5f5f5"/><stop offset="100%" stop-color="#90a4ae"/>

    </linearGradient>

    <linearGradient id="rank3Grad" x1="0%" y1="0%" x2="100%" y2="0%">

      <stop offset="0%" stop-color="#ffccbc"/><stop offset="100%" stop-color="#bf360c"/>

    </linearGradient>

    <linearGradient id="premiumGrad" x1="0%" y1="0%" x2="100%" y2="0%">

      <stop offset="0%" stop-color="#ffd54f"/><stop offset="100%" stop-color="#ff8f00"/>

    </linearGradient>

    <linearGradient id="normalGrad" x1="0%" y1="0%" x2="100%" y2="0%">

      <stop offset="0%" stop-color="#80deea"/><stop offset="100%" stop-color="#0097a7"/>

    </linearGradient>

    <linearGradient id="statGrad" x1="0%" y1="0%" x2="100%" y2="0%">

      <stop offset="0%" stop-color="#e8f4ff"/><stop offset="100%" stop-color="#9ec9e8"/>

    </linearGradient>

    <filter id="titleGlow" x="-30%" y="-30%" width="160%" height="160%">

      <feDropShadow dx="0" dy="0" stdDeviation="2" flood-color="#ffffff" flood-opacity="0.9"/>

      <feDropShadow dx="0" dy="2" stdDeviation="5" flood-color="#8eb8d8" flood-opacity="0.45"/>

    </filter>

    <filter id="glowRank1" x="-35%" y="-35%" width="170%" height="170%">

      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#ffd54f" flood-opacity="0.75"/>

    </filter>

    <filter id="glowRank2" x="-35%" y="-35%" width="170%" height="170%">

      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#eceff1" flood-opacity="0.7"/>

    </filter>

    <filter id="glowRank3" x="-35%" y="-35%" width="170%" height="170%">

      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#ffab91" flood-opacity="0.7"/>

    </filter>

    <filter id="glowPremium" x="-35%" y="-35%" width="170%" height="170%">

      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#ffca28" flood-opacity="0.75"/>

    </filter>

    <filter id="glowNormal" x="-35%" y="-35%" width="170%" height="170%">

      <feDropShadow dx="0" dy="0" stdDeviation="3" flood-color="#4dd0e1" flood-opacity="0.7"/>

    </filter>

  </defs>`);
  parts.push(
    `<rect x="${cardX}" y="${cardY}" width="${cardW}" height="${cardH}" rx="20" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.28)" stroke-width="1.5"/>`
  );
  let curY = cardY + 34;
  parts.push(
    `<text x="${innerX}" y="${curY}" font-family="${font}" font-size="32" font-weight="900" fill="${mainFill}" filter="url(#titleGlow)">我的鱼篓</text>`
  );
  parts.push(
    `<text x="${innerX}" y="${curY + 26}" font-family="${font}" font-size="13" fill="rgba(255,255,255,0.82)">${userName} · QQ ${userId}</text>`
  );
  if (time) {
    parts.push(
      `<text x="${cardX + cardW - 20}" y="${curY}" text-anchor="end" font-family="${font}" font-size="12" fill="rgba(255,255,255,0.65)">${time}</text>`
    );
  }
  const pageIndex = Math.max(1, Number(opts.pageIndex) || 1);
  const pageTotal = Math.max(1, Number(opts.pageTotal) || 1);
  parts.push(
    `<text x="${cardX + cardW - 20}" y="${curY + 22}" text-anchor="end" font-family="${font}" font-size="11" fill="rgba(255,255,255,0.5)">第 ${pageIndex}/${pageTotal} 页 · 三列 · 从重到轻</text>`
  );
  curY += 46;
  const statW = (contentW - 30) / 4;
  const stats = [
    { label: "总条数", value: `${opts.totalCount} 条` },
    { label: "总价值", value: totalValue },
    { label: "鱼种类", value: `${opts.categoryCount} 类` },
    { label: "规格记录", value: `${opts.recordCount} 条` }
  ];
  stats.forEach((st, i) => {
    const x = innerX + i * (statW + 10);
    parts.push(
      `<rect x="${x}" y="${curY}" width="${statW}" height="56" rx="12" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.28)" stroke-width="1"/>`
    );
    parts.push(
      `<text x="${x + 12}" y="${curY + 20}" font-family="${font}" font-size="11" fill="rgba(255,255,255,0.65)">${escapeXml$4(st.label)}</text>`
    );
    parts.push(
      `<text x="${x + 12}" y="${curY + 42}" font-family="${font}" font-size="16" font-weight="900" fill="url(#statGrad)" filter="url(#titleGlow)">${escapeXml$4(st.value)}</text>`
    );
  });
  curY = cardY + headerH;
  let tierCats = [];
  let pendingTier = null;
  const flushTierSection = () => {
    if (!tierCats.length || !pendingTier) return;
    const label = pendingTier === "premium" ? "◆ 高级渔获区" : "◇ 普通渔获区";
    const fill = pendingTier === "premium" ? "rgba(255,193,7,0.22)" : "rgba(255,255,255,0.14)";
    const stroke = pendingTier === "premium" ? "rgba(255,213,79,0.45)" : "rgba(255,255,255,0.28)";
    parts.push(`<rect x="${innerX}" y="${curY}" width="${contentW}" height="${density.tierH}" rx="8" fill="${fill}" stroke="${stroke}" stroke-width="1"/>`);
    parts.push(
      `<text x="${innerX + 14}" y="${curY + density.tierH - 11}" font-family="${font}" font-size="${density.nameSize + 1}" font-weight="900" fill="${mainFill}">${label}</text>`
    );
    curY += density.tierH + 8;
    const cols = distributeCategoriesToColumns(tierCats, density);
    const colStarts = cols.map((_, idx) => innerX + idx * (colW + density.colGap));
    const colRendered = cols.map(
      (cats, idx) => renderColumnCategories(cats, colStarts[idx], curY, colW, density, font, mainFill)
    );
    const maxColH = Math.max(...colRendered.map((c) => c.height), 0);
    for (const col of colRendered) {
      parts.push(...col.parts);
    }
    curY += maxColH + 12;
    tierCats = [];
    pendingTier = null;
  };
  for (const line of lines) {
    if (line.type === "tier") {
      flushTierSection();
      pendingTier = line.tier;
    } else if (line.type === "category") {
      tierCats.push(line);
    }
  }
  flushTierSection();
  parts.push(
    `<text x="${width / 2}" y="${cardY + cardH - 14}" text-anchor="middle" font-family="${font}" font-size="10" fill="rgba(255,255,255,0.42)">${escapeXml$4("MK-Bot · 出售: 出售 全部鱼 / 出售 鱼名(重量kg) [数量]")}</text>`
  );
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${parts.join("\n")}</svg>`;
}
async function renderFishBasketWithSharpImpl(options, logger) {
  const displayItems = (options.items || []).slice(0, FISH_BASKET_PER_PAGE);
  const density = pickDensity(displayItems.length);
  const width = options.width ?? density.width;
  const rankOffset = Math.max(0, Number(options.rankOffset) || 0);
  const lines = buildFishBasketRenderLines(displayItems, rankOffset);
  const height = calcFishBasketCanvasHeight(lines, density);
  const pluginDir = String(options.pluginDir || "").trim();
  const dataPath = String(options.dataPath || "").trim();
  const bgLocalPath = String(options.bgLocalPath || "").trim();
  try {
    const sharp = await loadSharp();
    const composites = [];
    const bgBuf = await loadFishBasketBackground(bgLocalPath, pluginDir, dataPath);
    if (bgBuf && bgBuf.length > 0) {
      await applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath);
    } else {
      const fallback = await sharp({
        create: {
          width,
          height,
          channels: 4,
          background: { r: 22, g: 28, b: 38, alpha: 1 }
        }
      }).png().toBuffer();
      composites.push({ input: fallback, top: 0, left: 0 });
      logger?.warn?.("[Sharp渲染] 我的鱼篓背景图不可用，已使用默认底色");
    }
    const svg = buildFishBasketSvg(width, height, options, lines, density, loadSharpTextColorFromDataPath(dataPath));
    const uiLayer = await fitCompositeLayer$1(sharp, Buffer.from(svg), width, height);
    composites.push({ input: uiLayer, top: 0, left: 0 });
    const out = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 18, g: 22, b: 30, alpha: 1 }
      }
    }).composite(composites).png({ compressionLevel: 6 }).toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

async function fetchQqAvatarBuffer(qq) {
  const id = String(qq ?? "").trim();
  if (!id || !/^\d{5,12}$/.test(id)) return null;
  const url = `https://q1.qlogo.cn/g?b=qq&nk=${id}&s=5`;
  try {
    const res = await fetch(url, {
      signal: AbortSignal.timeout(5e3),
      headers: { "User-Agent": "Mozilla/5.0" }
    });
    if (!res.ok) return null;
    const ab = await res.arrayBuffer();
    if (!ab || ab.byteLength < 32) return null;
    return Buffer.from(ab);
  } catch {
    return null;
  }
}
async function fetchUrlImageBuffer(url) {
  const u = String(url ?? "").trim();
  if (!/^https?:\/\//i.test(u)) return null;
  try {
    const res = await fetch(u, {
      signal: AbortSignal.timeout(8e3),
      headers: { "User-Agent": "Mozilla/5.0" }
    });
    if (!res.ok) return null;
    const ab = await res.arrayBuffer();
    if (!ab || ab.byteLength < 32) return null;
    return Buffer.from(ab);
  } catch {
    return null;
  }
}
async function prepareAvatarPng(sharp, avatarBuf, options = {}) {
  const circle = options.circle !== false;
  const size = Math.max(0, Math.floor(Number(options.size) || 0));
  const meta = await sharp(avatarBuf).metadata();
  const aw = Number(meta.width) || 0;
  const ah = Number(meta.height) || 0;
  let pipeline = sharp(avatarBuf).rotate().ensureAlpha();
  if (aw > 0 && ah > 0 && aw !== ah) {
    const side2 = Math.min(aw, ah);
    const left = Math.floor((aw - side2) / 2);
    const top = Math.floor((ah - side2) / 2);
    pipeline = sharp(avatarBuf).rotate().extract({ left, top, width: side2, height: side2 }).ensureAlpha();
  }
  if (size > 0) {
    pipeline = pipeline.resize(size, size, { fit: "fill", kernel: "lanczos3" });
  }
  let png = await pipeline.png().toBuffer();
  if (!circle) return png;
  const info = await sharp(png).metadata();
  const side = Math.max(1, Number(info.width) || size || 100);
  const mask = Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${side}" height="${side}"><circle cx="${side / 2}" cy="${side / 2}" r="${side / 2}" fill="white"/></svg>`
  );
  return sharp(png).ensureAlpha().composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
}
async function prepareAvatarOvalFitPng(sharp, avatarBuf, maxW, maxH) {
  const png = await sharp(avatarBuf).rotate().resize(maxW, maxH, { fit: "inside", kernel: "linear" }).ensureAlpha().png().toBuffer();
  const info = await sharp(png).metadata();
  const w = Math.max(1, Number(info.width) || maxW);
  const h = Math.max(1, Number(info.height) || maxH);
  const mask = Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><ellipse cx="${w / 2}" cy="${h / 2}" rx="${w / 2}" ry="${h / 2}" fill="white"/></svg>`
  );
  return sharp(png).ensureAlpha().composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
}
async function composeAvatarUnderTemplate(sharp, templatePath2, avatarPng, loc) {
  const tplMeta = await sharp(templatePath2).metadata();
  const cw = Math.max(1, Number(tplMeta.width) || 1);
  const ch = Math.max(1, Number(tplMeta.height) || 1);
  const w = Math.max(1, Math.floor(loc.w));
  const h = Math.max(1, Math.floor(loc.h));
  const x = Math.floor(loc.x);
  const y = Math.floor(loc.y);
  const avatarResized = await sharp(avatarPng).resize(w, h, { fit: "fill", kernel: "linear" }).png().toBuffer();
  const templatePng = await sharp(templatePath2).ensureAlpha().png().toBuffer();
  return sharp({
    create: {
      width: cw,
      height: ch,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 }
    }
  }).composite([
    { input: avatarResized, left: x, top: y },
    { input: templatePng, left: 0, top: 0 }
  ]).png().toBuffer();
}
async function composeAvatarOverTemplate(sharp, templatePath2, avatarPng, loc) {
  const w = Math.max(1, Math.floor(loc.w));
  const h = Math.max(1, Math.floor(loc.h));
  const x = Math.floor(loc.x);
  const y = Math.floor(loc.y);
  const avatarResized = await sharp(avatarPng).resize(w, h, { fit: "fill", kernel: "linear" }).png().toBuffer();
  return sharp(templatePath2).ensureAlpha().composite([{ input: avatarResized, left: x, top: y }]).png().toBuffer();
}
async function composeAvatarOnWhiteWithTemplate(sharp, templatePath2, avatarPng, loc) {
  const tplMeta = await sharp(templatePath2).metadata();
  const cw = Math.max(1, Number(tplMeta.width) || 1);
  const ch = Math.max(1, Number(tplMeta.height) || 1);
  const w = Math.max(1, Math.floor(loc.w));
  const h = Math.max(1, Math.floor(loc.h));
  const x = Math.floor(loc.x);
  const y = Math.floor(loc.y);
  const avatarResized = await sharp(avatarPng).resize(w, h, { fit: "fill", kernel: "linear" }).png().toBuffer();
  const templatePng = await sharp(templatePath2).ensureAlpha().png().toBuffer();
  return sharp({
    create: {
      width: cw,
      height: ch,
      channels: 4,
      background: { r: 255, g: 255, b: 255, alpha: 1 }
    }
  }).composite([
    { input: avatarResized, left: x, top: y },
    { input: templatePng, left: 0, top: 0 }
  ]).png().toBuffer();
}
async function composeRubFrame(sharp, templatePath2, selfAvatarPng, targetAvatarPng, targetLoc, selfLoc) {
  const targetResized = await sharp(targetAvatarPng).resize(Math.max(1, Math.floor(targetLoc.w)), Math.max(1, Math.floor(targetLoc.h)), {
    fit: "fill",
    kernel: "lanczos3"
  }).png().toBuffer();
  let selfPipeline = sharp(selfAvatarPng).resize(
    Math.max(1, Math.floor(selfLoc.w)),
    Math.max(1, Math.floor(selfLoc.h)),
    { fit: "fill", kernel: "lanczos3" }
  );
  const angle = Number(selfLoc.angle) || 0;
  if (angle !== 0) {
    selfPipeline = selfPipeline.rotate(angle, { background: { r: 0, g: 0, b: 0, alpha: 0 } });
  }
  const selfResized = await selfPipeline.png().toBuffer();
  return sharp(templatePath2).ensureAlpha().composite([
    { input: targetResized, left: Math.floor(targetLoc.x), top: Math.floor(targetLoc.y) },
    { input: selfResized, left: Math.floor(selfLoc.x), top: Math.floor(selfLoc.y) }
  ]).png().toBuffer();
}
async function encodeGifFromPngFrames(sharp, frames, delayMs) {
  if (!frames.length) throw new Error("bqb: empty gif frames");
  const firstMeta = await sharp(frames[0]).metadata();
  const fw = Math.max(1, Number(firstMeta.width) || 1);
  const fh = Math.max(1, Number(firstMeta.height) || 1);
  const normalized = [];
  for (const frame of frames) {
    normalized.push(
      await sharp(frame).ensureAlpha().resize(fw, fh, { fit: "fill" }).png().toBuffer()
    );
  }
  const delays = Array.isArray(delayMs) ? delayMs.map((d) => Math.max(20, Math.floor(d))) : Math.max(20, Math.floor(delayMs));
  return sharp({
    create: {
      width: fw,
      height: fh * normalized.length,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 },
      pageHeight: fh
    }
  }).composite(normalized.map((input, i) => ({ input, left: 0, top: i * fh }))).gif({
    delay: delays,
    loop: 0,
    effort: 1
  }).toBuffer();
}
async function getBqbSharp() {
  return loadSharp();
}
function resolveBqbSubdir(kind, dataPath, pluginDir) {
  const rel = path.join("默认资源", "image", "api", "bqb", kind);
  const pluginDirSafe = String(pluginDir || "").trim();
  const candidates = [
    path.join(pluginDirSafe, rel)
  ];
  for (const p of candidates) {
    if (p && fs.existsSync(p)) return p;
  }
  return candidates[0] || "";
}
function templatePath(dir, index, ext, pad = 0) {
  const name = pad > 0 ? `${String(index).padStart(pad, "0")}.${ext}` : `${index}.${ext}`;
  return path.join(dir, name);
}

const MUSIC_LIST_MAX_ITEMS = 20;
function escapeXml$3(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function truncateText$1(text, maxLen) {
  const s = String(text || "").trim();
  if (s.length <= maxLen) return s;
  return `${s.slice(0, maxLen - 1)}…`;
}
async function loadMusicListBackground(bgLocalPath, pluginDir, dataPath) {
  const candidates = [];
  const push = (v) => {
    const s = String(v || "").trim();
    if (s && !candidates.includes(s)) candidates.push(s);
  };
  push(bgLocalPath);
  const roots = [
    path.join(String(pluginDir || "").trim(), "默认资源", "image"),
    path.join(String(dataPath || "").trim(), "默认资源", "image")
  ];
  for (const root of roots) {
    if (!root.trim()) continue;
    push(path.join(root, "运势6.png"));
  }
  for (const src of candidates) {
    try {
      const abs = path.isAbsolute(src) ? src : path.resolve(src);
      if (fs.existsSync(abs)) {
        const buf = fs.readFileSync(abs);
        if (buf.length > 0) return buf;
      }
    } catch {
    }
  }
  return null;
}
async function roundCover(sharp, buf, size) {
  try {
    const mask = Buffer.from(
      `<svg width="${size}" height="${size}"><rect x="0" y="0" width="${size}" height="${size}" rx="12" ry="12" fill="white"/></svg>`
    );
    return sharp(buf).resize(size, size, { fit: "cover" }).ensureAlpha().composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
  } catch {
    return null;
  }
}
async function makeFallbackCover(sharp, size) {
  return sharp({
    create: {
      width: size,
      height: size,
      channels: 4,
      background: { r: 80, g: 90, b: 110, alpha: 0.85 }
    }
  }).png().toBuffer();
}
function buildMusicListSvg(width, height, opts) {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const { source, query, count, items, rowH, coverSize, padX, headerH, customText } = opts;
  const titleFill = resolveSharpTextFill(customText, "#fff6e8");
  const subFill = resolveSharpTextFill(customText, "rgba(255,255,255,0.88)");
  const idxFill = resolveSharpTextFill(customText, "#fff3dc");
  const mainFill = resolveSharpTextFill(customText, "#fff8ee");
  const parts = [];
  parts.push(
    `<text x="${width / 2}" y="48" text-anchor="middle" font-family="${font}" font-size="36" font-weight="800" fill="${titleFill}">点歌列表</text>`
  );
  parts.push(
    `<text x="${width / 2}" y="78" text-anchor="middle" font-family="${font}" font-size="16" fill="${subFill}">【${escapeXml$3(source)}】共 ${count} 首${query ? ` · ${escapeXml$3(truncateText$1(query, 18))}` : ""}</text>`
  );
  const listTop = headerH;
  const listLeft = padX;
  const listW = width - padX * 2;
  const listH = items.length * rowH + 16;
  parts.push(
    `<rect x="${listLeft}" y="${listTop}" width="${listW}" height="${listH}" rx="20" ry="20" fill="rgba(0,0,0,0.28)" stroke="rgba(255,255,255,0.22)" stroke-width="1"/>`
  );
  items.forEach((item, i) => {
    const y = listTop + 8 + i * rowH;
    const alt = i % 2 === 1;
    parts.push(
      `<rect x="${listLeft + 4}" y="${y}" width="${listW - 8}" height="${rowH - 4}" rx="12" ry="12" fill="${alt ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.04)"}"/>`
    );
    const idxX = listLeft + 28;
    const idxY = y + rowH / 2 + 6;
    parts.push(
      `<text x="${idxX}" y="${idxY}" text-anchor="middle" font-family="${font}" font-size="22" font-weight="800" fill="${idxFill}">${escapeXml$3(String(item.index))}</text>`
    );
    const textX = listLeft + 28 + 28 + coverSize + 16;
    const title = truncateText$1(item.title || "未知歌名", 22);
    const artist = truncateText$1(item.artist || "未知歌手", 26);
    parts.push(
      `<text x="${textX}" y="${y + 34}" font-family="${font}" font-size="20" font-weight="700" fill="${mainFill}">${escapeXml$3(title)}</text>`
    );
    parts.push(
      `<text x="${textX}" y="${y + 60}" font-family="${font}" font-size="14" fill="rgba(255,255,255,0.78)">${escapeXml$3(artist)}</text>`
    );
  });
  parts.push(
    `<text x="${width / 2}" y="${height - 22}" text-anchor="middle" font-family="${font}" font-size="13" fill="rgba(255,255,255,0.55)">发送「选歌N」/「卡片选歌N」/「语音选歌N」/「链接选歌N」</text>`
  );
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${parts.join("\n")}</svg>`;
}
async function renderMusicListWithSharpImpl(options, logger) {
  const rawItems = Array.isArray(options.items) ? options.items : [];
  const items = rawItems.slice(0, MUSIC_LIST_MAX_ITEMS).map((it, i) => ({
    index: Number(it.index) || i + 1,
    title: String(it.title || "").trim(),
    artist: String(it.artist || "").trim(),
    coverUrl: String(it.coverUrl || "").trim()
  }));
  if (!items.length) return null;
  const width = options.width ?? 900;
  const rowH = 88;
  const coverSize = 64;
  const padX = 28;
  const headerH = 100;
  const footerH = 52;
  const height = Math.max(360, headerH + items.length * rowH + 24 + footerH);
  const pluginDir = String(options.pluginDir || "").trim();
  const dataPath = String(options.dataPath || "").trim();
  const bgLocalPath = String(options.bgLocalPath || "").trim();
  const source = String(options.source || "网易云").trim() || "网易云";
  const query = String(options.query || "").trim();
  const botSelfId = options.botSelfId;
  try {
    const sharp = await loadSharp();
    let botAvatarBuf = null;
    try {
      botAvatarBuf = await fetchQqAvatarBuffer(botSelfId ?? "");
    } catch {
      botAvatarBuf = null;
    }
    const coverBufs = await Promise.all(
      items.map(async (it) => {
        if (it.coverUrl) {
          const buf = await fetchUrlImageBuffer(it.coverUrl);
          if (buf && buf.length > 32) return buf;
        }
        if (botAvatarBuf && botAvatarBuf.length > 32) return botAvatarBuf;
        return null;
      })
    );
    const composites = [];
    const bgBuf = await loadMusicListBackground(bgLocalPath, pluginDir, dataPath);
    if (bgBuf && bgBuf.length > 0) {
      await applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath);
    } else {
      const fallback = await sharp({
        create: {
          width,
          height,
          channels: 4,
          background: { r: 28, g: 36, b: 52, alpha: 1 }
        }
      }).png().toBuffer();
      composites.push({ input: fallback, top: 0, left: 0 });
    }
    const customText = loadSharpTextColorFromDataPath(dataPath);
    const svg = buildMusicListSvg(width, height, {
      source,
      query,
      count: items.length,
      items,
      rowH,
      coverSize,
      padX,
      headerH,
      customText
    });
    const uiLayer = await sharp(Buffer.from(svg)).ensureAlpha().png().toBuffer();
    composites.push({ input: uiLayer, top: 0, left: 0 });
    const listTop = headerH;
    const listLeft = padX;
    const coverLeft = listLeft + 28 + 28;
    const solidFallback = await makeFallbackCover(sharp, coverSize);
    for (let i = 0; i < items.length; i++) {
      const y = listTop + 8 + i * rowH;
      const coverTop = Math.round(y + (rowH - 4 - coverSize) / 2);
      let raw = coverBufs[i];
      if (!raw || raw.length < 32) raw = botAvatarBuf;
      let rounded = null;
      if (raw && raw.length >= 32) {
        rounded = await roundCover(sharp, raw, coverSize);
      }
      composites.push({
        input: rounded || solidFallback,
        top: Math.max(0, coverTop),
        left: coverLeft
      });
    }
    const out = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 15, g: 25, b: 35, alpha: 1 }
      }
    }).composite(composites).png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

function glassRect(x, y, w, h, r = 18) {
  return [
    `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${r}" ry="${r}" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.28)" stroke-width="1.5"/>`,
    `<rect x="${x + 1}" y="${y + 1}" width="${w - 2}" height="${Math.max(10, Math.floor(h * 0.22))}" rx="${Math.max(8, r - 4)}" ry="${Math.max(8, r - 4)}" fill="rgba(255,255,255,0.08)"/>`
  ].join("\n");
}
function joinIdentityDefs() {
  return `<defs>
    <linearGradient id="valGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="100%" stop-color="#c8e7ff"/>
    </linearGradient>
    <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#e8f4ff"/>
      <stop offset="100%" stop-color="#9ec9e8"/>
    </linearGradient>
    <filter id="titleGlow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="0" stdDeviation="2" flood-color="#ffffff" flood-opacity="0.85"/>
      <feDropShadow dx="0" dy="1" stdDeviation="4" flood-color="#8eb8d8" flood-opacity="0.35"/>
    </filter>
    <filter id="valGlow" x="-35%" y="-35%" width="170%" height="170%">
      <feDropShadow dx="0" dy="0" stdDeviation="2" flood-color="#ffffff" flood-opacity="0.55"/>
      <feDropShadow dx="0" dy="1" stdDeviation="5" flood-color="#9ec9e8" flood-opacity="0.35"/>
    </filter>
  </defs>`;
}
function escapeXml$2(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function truncateText(text, maxLen) {
  const s = String(text).trim();
  if (s.length <= maxLen) return s;
  return `${s.slice(0, maxLen - 1)}…`;
}
function fetchUrlBuffer(url, timeoutMs = 12e3) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith("https") ? https : http;
    const req = lib.get(
      url,
      { timeout: timeoutMs, headers: { "User-Agent": "MKbot-JoinIdentitySharp/1.0" } },
      (res) => {
        if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          fetchUrlBuffer(res.headers.location, timeoutMs).then(resolve).catch(reject);
          return;
        }
        if (res.statusCode && res.statusCode >= 400) {
          reject(new Error(`HTTP ${res.statusCode}`));
          res.resume();
          return;
        }
        const chunks = [];
        res.on("data", (c) => chunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c)));
        res.on("end", () => resolve(Buffer.concat(chunks)));
        res.on("error", reject);
      }
    );
    req.on("error", reject);
    req.on("timeout", () => req.destroy(new Error("timeout")));
  });
}
async function loadJoinIdentityBackground(bgLocalPath, pluginDir, dataPath) {
  const candidates = [];
  const push = (v) => {
    const s = String(v || "").trim();
    if (s && !candidates.includes(s)) candidates.push(s);
  };
  push(bgLocalPath);
  const localNames = ["heng.jpg", "heng.jpeg", "heng.png", "heng.webp"];
  const roots = [
    path.join(String(pluginDir || "").trim(), "默认资源", "image"),
    path.join(String(dataPath || "").trim(), "默认资源", "image")
  ];
  try {
    const here = path.dirname(fileURLToPath(import.meta.url));
    roots.push(path.join(here, "..", "默认资源", "image"));
  } catch {
  }
  for (const root of roots) {
    if (!String(root || "").trim()) continue;
    for (const name of localNames) {
      push(path.join(root, name));
    }
  }
  for (const src of candidates) {
    try {
      if (/^https?:\/\//i.test(src)) {
        const buf = await fetchUrlBuffer(src, 2e4);
        if (buf.length > 0) return buf;
        continue;
      }
      const abs = path.isAbsolute(src) ? src : path.resolve(src);
      if (fs.existsSync(abs)) {
        const buf = fs.readFileSync(abs);
        if (buf.length > 0) return buf;
      }
    } catch {
    }
  }
  return null;
}
async function fitCompositeLayer(sharp, input, width, height) {
  return sharp(input).resize(width, height, { fit: "fill" }).ensureAlpha().png().toBuffer();
}
function calcJoinIdentityLayout(width, height) {
  const pad = 40;
  const headerH = 88;
  const avatarSize = 196;
  const avatarCenterY = pad + headerH + 36 + avatarSize / 2;
  return {
    avatarSize,
    avatarLeft: Math.round(width / 2 - avatarSize / 2),
    avatarTop: Math.round(avatarCenterY - avatarSize / 2)
  };
}
function buildJoinIdentitySvg(width, height, opts, layout, customText) {
  const font = "Microsoft YaHei, Noto Sans SC, sans-serif";
  const mainFill = resolveSharpTextFill(customText, "#ffffff");
  const pad = 40;
  const cardX = pad;
  const cardY = pad;
  const cardW = width - pad * 2;
  const cardH = height - pad * 2;
  const cx = width / 2;
  const qq = escapeXml$2(String(opts.qq || ""));
  const name = escapeXml$2(truncateText(opts.name || "新成员", 14));
  const sex = escapeXml$2(String(opts.sex || "未知"));
  const birthday = escapeXml$2(String(opts.birthday || "-"));
  const age = escapeXml$2(String(opts.age || "0"));
  const qqLevel = escapeXml$2(String(opts.qqLevel || "0"));
  const regTime = escapeXml$2(String(opts.regTime || "-"));
  const joinTime = escapeXml$2(String(opts.joinTime || "-"));
  const avatarCx = layout.avatarLeft + layout.avatarSize / 2;
  const avatarCy = layout.avatarTop + layout.avatarSize / 2;
  const avatarR = layout.avatarSize / 2;
  const nameY = layout.avatarTop + layout.avatarSize + 44;
  const qqY = nameY + 34;
  const badgeY = qqY + 36;
  const gridY = badgeY + 40;
  const gridPad = 36;
  const gridW = cardW - gridPad * 2;
  const colGap = 16;
  const rowGap = 16;
  const colW = (gridW - colGap * 3) / 4;
  const rowH = 108;
  const wideW = (gridW - colGap) / 2;
  const parts = [];
  parts.push(joinIdentityDefs());
  parts.push(glassRect(cardX, cardY, cardW, cardH, 32));
  const headerY = cardY + 36;
  parts.push(
    `<text x="${cardX + gridPad}" y="${headerY}" font-family="${font}" font-size="30" font-weight="900" fill="${mainFill}" filter="url(#titleGlow)">入群身份</text>`
  );
  parts.push(
    `<text x="${cardX + gridPad}" y="${headerY + 26}" font-family="${font}" font-size="13" fill="rgba(255,255,255,0.72)" letter-spacing="1.5">WELCOME CARD</text>`
  );
  parts.push(
    `<text x="${cardX + cardW - gridPad}" y="${headerY}" text-anchor="end" font-family="${font}" font-size="13" fill="rgba(255,255,255,0.82)">${joinTime}</text>`
  );
  parts.push(
    `<text x="${cardX + cardW - gridPad}" y="${headerY + 22}" text-anchor="end" font-family="${font}" font-size="11" fill="rgba(255,255,255,0.5)">加群时间</text>`
  );
  parts.push(
    `<circle cx="${avatarCx}" cy="${avatarCy}" r="${avatarR + 6}" fill="none" stroke="rgba(255,255,255,0.35)" stroke-width="2.5"/>`
  );
  parts.push(
    `<circle cx="${avatarCx}" cy="${avatarCy}" r="${avatarR}" fill="rgba(255,255,255,0.1)" stroke="rgba(255,255,255,0.45)" stroke-width="3"/>`
  );
  parts.push(
    `<text x="${cx}" y="${nameY}" text-anchor="middle" font-family="${font}" font-size="34" font-weight="900" fill="url(#valGrad)" filter="url(#valGlow)">${name}</text>`
  );
  parts.push(
    `<text x="${cx}" y="${qqY}" text-anchor="middle" font-family="${font}" font-size="16" fill="rgba(255,255,255,0.82)">QQ · ${qq}</text>`
  );
  const badges = [
    { text: sex, x: cx - 130 },
    { text: `${age}岁`, x: cx },
    { text: `Lv.${qqLevel}`, x: cx + 130 }
  ];
  badges.forEach((b) => {
    const bw = 108;
    const bh = 30;
    const bx = b.x - bw / 2;
    const by = badgeY - 22;
    parts.push(glassRect(bx, by, bw, bh, 15));
    parts.push(
      `<text x="${b.x}" y="${badgeY}" text-anchor="middle" font-family="${font}" font-size="14" font-weight="800" fill="url(#accentGrad)" filter="url(#valGlow)">${escapeXml$2(b.text)}</text>`
    );
  });
  const drawTile = (x, y, w, h, label, value, accent = false) => {
    parts.push(glassRect(x, y, w, h, 16));
    parts.push(
      `<circle cx="${x + 18}" cy="${y + 22}" r="4" fill="rgba(200,231,255,0.9)"/>`
    );
    parts.push(
      `<text x="${x + 32}" y="${y + 26}" font-family="${font}" font-size="12" font-weight="600" fill="rgba(255,255,255,0.72)">${escapeXml$2(label)}</text>`
    );
    if (accent) {
      parts.push(
        `<text x="${x + 18}" y="${y + 72}" font-family="${font}" font-size="24" font-weight="900" fill="url(#valGrad)" filter="url(#valGlow)">${escapeXml$2(value)}</text>`
      );
    } else {
      parts.push(
        `<text x="${x + 18}" y="${y + 68}" font-family="${font}" font-size="20" font-weight="700" fill="${mainFill}">${escapeXml$2(value)}</text>`
      );
    }
  };
  const gx = cardX + gridPad;
  const tiles = [
    { label: "性别", value: sex, accent: true },
    { label: "年龄", value: `${age}岁`, accent: true },
    { label: "QQ等级", value: `${qqLevel}级`, accent: true },
    { label: "生日", value: birthday, accent: true }
  ];
  tiles.forEach((tile, i) => {
    const x = gx + i * (colW + colGap);
    drawTile(x, gridY, colW, rowH, tile.label, tile.value, tile.accent);
  });
  const row2Y = gridY + rowH + rowGap;
  drawTile(gx, row2Y, wideW, rowH, "注册时间", regTime);
  drawTile(gx + wideW + colGap, row2Y, wideW, rowH, "加群时间", joinTime);
  parts.push(
    `<text x="${cx}" y="${cardY + cardH - 18}" text-anchor="middle" font-family="${font}" font-size="11" fill="rgba(255,255,255,0.38)" letter-spacing="2">MK-Bot · 入群欢迎</text>`
  );
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${parts.join("\n")}</svg>`;
}
async function roundAvatar(sharp, buf, size) {
  try {
    const mask = Buffer.from(
      `<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="white"/></svg>`
    );
    return sharp(buf).resize(size, size, { fit: "cover" }).ensureAlpha().composite([{ input: mask, blend: "dest-in" }]).png().toBuffer();
  } catch {
    return null;
  }
}
async function renderJoinIdentityWithSharpImpl(options, logger) {
  const width = options.width ?? 1400;
  const height = options.height ?? 850;
  const layout = calcJoinIdentityLayout(width);
  const pluginDir = String(options.pluginDir || "").trim();
  const dataPath = String(options.dataPath || "").trim();
  const bgLocalPath = String(options.bgLocalPath || "").trim();
  try {
    const sharp = await loadSharp();
    const composites = [];
    const bgBuf = await loadJoinIdentityBackground(bgLocalPath, pluginDir, dataPath);
    if (bgBuf && bgBuf.length > 0) {
      await applySharpPhotoBackgroundLayers(sharp, composites, bgBuf, width, height, dataPath);
    } else {
      const fallback = await sharp({
        create: {
          width,
          height,
          channels: 4,
          background: { r: 22, g: 28, b: 38, alpha: 1 }
        }
      }).png().toBuffer();
      composites.push({ input: fallback, top: 0, left: 0 });
      logger?.warn?.("[Sharp渲染] 入群身份背景图不可用，已使用默认底色");
    }
    const customText = loadSharpTextColorFromDataPath(dataPath);
    const svg = buildJoinIdentitySvg(width, height, options, layout, customText);
    const uiLayer = await fitCompositeLayer(sharp, Buffer.from(svg), width, height);
    composites.push({ input: uiLayer, top: 0, left: 0 });
    const avatarUrl = `https://q4.qlogo.cn/g?b=qq&nk=${options.qq || ""}&s=5`;
    try {
      const avatarBuf = await fetchUrlBuffer(avatarUrl, 1e4);
      if (avatarBuf.length > 0) {
        const rounded = await roundAvatar(sharp, avatarBuf, layout.avatarSize);
        if (rounded) {
          composites.push({ input: rounded, top: layout.avatarTop, left: layout.avatarLeft });
        }
      }
    } catch (_e) {
    }
    const out = await sharp({
      create: {
        width,
        height,
        channels: 4,
        background: { r: 18, g: 22, b: 30, alpha: 1 }
      }
    }).composite(composites).png().toBuffer();
    return out.toString("base64");
  } catch (error) {
    error instanceof Error ? error.message : String(error);
    return null;
  }
}

async function render$j(input) {
  const dir = resolveBqbSubdir("crawl", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-crawl: 素材目录不存在");
  }
  let num = Math.floor(Number(input.num) || 0);
  if (num < 1 || num > 92) {
    num = 1 + Math.floor(Math.random() * 92);
  }
  const tpl = templatePath(dir, num, "jpg", 2);
  if (!fs.existsSync(tpl)) {
    throw new Error(`bqb-crawl: 模板不存在 ${num}`);
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: true, size: 100 });
  const composed = await sharp(tpl).ensureAlpha().composite([{ input: avatarPng, left: 0, top: 400 }]).jpeg({ quality: 90, mozjpeg: true }).toBuffer();
  return { buffer: composed, mime: "image/jpeg", ext: "jpg" };
}

const LOCS$5 = [
  { x: 180, y: 60, w: 100, h: 100 },
  { x: 184, y: 75, w: 100, h: 100 },
  { x: 183, y: 98, w: 100, h: 100 },
  { x: 179, y: 118, w: 110, h: 100 },
  { x: 156, y: 194, w: 150, h: 48 },
  { x: 178, y: 136, w: 122, h: 69 },
  { x: 175, y: 66, w: 122, h: 85 },
  { x: 170, y: 42, w: 130, h: 96 },
  { x: 175, y: 34, w: 118, h: 95 },
  { x: 179, y: 35, w: 110, h: 93 },
  { x: 180, y: 54, w: 102, h: 93 },
  { x: 183, y: 58, w: 97, h: 92 },
  { x: 174, y: 35, w: 120, h: 94 },
  { x: 179, y: 35, w: 109, h: 93 },
  { x: 181, y: 54, w: 101, h: 92 },
  { x: 182, y: 59, w: 98, h: 92 },
  { x: 183, y: 71, w: 90, h: 96 },
  { x: 180, y: 131, w: 92, h: 101 }
];
async function render$i(input) {
  const dir = resolveBqbSubdir("play", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-play: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: true });
  const imgFrames = [];
  for (let i = 0; i < 18; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-play: 模板不存在 ${i}`);
    imgFrames.push(await composeAvatarUnderTemplate(sharp, tpl, avatarPng, LOCS$5[i]));
  }
  const rawFrames = [];
  for (let i = 18; i < 38; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-play: 模板不存在 ${i}`);
    rawFrames.push(await sharp(tpl).ensureAlpha().png().toBuffer());
  }
  const sequence = [
    ...imgFrames.slice(0, 12),
    ...imgFrames.slice(0, 12),
    ...imgFrames.slice(0, 8),
    ...imgFrames.slice(12, 18),
    ...rawFrames
  ];
  const buffer = await encodeGifFromPngFrames(sharp, sequence, 60);
  return { buffer, mime: "image/gif", ext: "gif" };
}

const LOCS$4 = [
  { x: 90, y: 90, w: 105, h: 150 },
  { x: 90, y: 83, w: 96, h: 172 },
  { x: 90, y: 90, w: 106, h: 148 },
  { x: 88, y: 88, w: 97, h: 167 },
  { x: 90, y: 85, w: 89, h: 179 },
  { x: 90, y: 90, w: 106, h: 151 }
];
async function render$h(input) {
  const dir = resolveBqbSubdir("bite", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-bite: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: true });
  const frames = [];
  for (let i = 0; i < 6; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-bite: 模板不存在 ${i}`);
    frames.push(await composeAvatarUnderTemplate(sharp, tpl, avatarPng, LOCS$4[i]));
  }
  for (let i = 6; i < 16; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-bite: 模板不存在 ${i}`);
    frames.push(await sharp(tpl).ensureAlpha().png().toBuffer());
  }
  const buffer = await encodeGifFromPngFrames(sharp, frames, 70);
  return { buffer, mime: "image/gif", ext: "gif" };
}

const LOCS$3 = [
  { x: 14, y: 20, w: 98, h: 98 },
  { x: 12, y: 33, w: 101, h: 85 },
  { x: 8, y: 40, w: 110, h: 76 },
  { x: 10, y: 33, w: 102, h: 84 },
  { x: 12, y: 20, w: 98, h: 98 }
];
async function render$g(input) {
  const dir = resolveBqbSubdir("petpet", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-petpet: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, {
    circle: input.circle !== false
  });
  const frames = [];
  for (let i = 0; i < LOCS$3.length; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-petpet: 模板不存在 ${i}`);
    frames.push(await composeAvatarUnderTemplate(sharp, tpl, avatarPng, LOCS$3[i]));
  }
  const buffer = await encodeGifFromPngFrames(sharp, frames, 60);
  return { buffer, mime: "image/gif", ext: "gif" };
}

const LOC = { x: 2, y: 38, w: 34, h: 34 };
async function render$f(input) {
  const dir = resolveBqbSubdir("eat", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-eat: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: false });
  const frames = [];
  for (let i = 0; i < 3; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-eat: 模板不存在 ${i}`);
    frames.push(await composeAvatarOnWhiteWithTemplate(sharp, tpl, avatarPng, LOC));
  }
  const buffer = await encodeGifFromPngFrames(sharp, frames, 50);
  return { buffer, mime: "image/gif", ext: "gif" };
}

const LOCS$2 = [
  { x: 82, y: 100, w: 130, h: 119 },
  { x: 82, y: 94, w: 126, h: 125 },
  { x: 82, y: 120, w: 128, h: 99 },
  { x: 81, y: 164, w: 132, h: 55 },
  { x: 79, y: 163, w: 132, h: 55 },
  { x: 82, y: 140, w: 127, h: 79 },
  { x: 83, y: 152, w: 125, h: 67 },
  { x: 75, y: 157, w: 140, h: 62 },
  { x: 72, y: 165, w: 144, h: 54 },
  { x: 80, y: 132, w: 128, h: 87 },
  { x: 81, y: 127, w: 127, h: 92 },
  { x: 79, y: 111, w: 132, h: 108 }
];
async function render$e(input) {
  const dir = resolveBqbSubdir("suck", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-suck: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: true });
  const frames = [];
  for (let i = 0; i < LOCS$2.length; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-suck: 模板不存在 ${i}`);
    frames.push(await composeAvatarOnWhiteWithTemplate(sharp, tpl, avatarPng, LOCS$2[i]));
  }
  const buffer = await encodeGifFromPngFrames(sharp, frames, 80);
  return { buffer, mime: "image/gif", ext: "gif" };
}

async function render$d(input) {
  const dir = resolveBqbSubdir("jiujiu", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-jiujiu: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarOvalFitPng(sharp, input.avatar, 75, 51);
  const frames = [];
  for (let i = 0; i < 8; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-jiujiu: 模板不存在 ${i}`);
    const tplMeta = await sharp(tpl).metadata();
    const cw = Math.max(1, Number(tplMeta.width) || 1);
    const ch = Math.max(1, Number(tplMeta.height) || 1);
    const templatePng = await sharp(tpl).ensureAlpha().png().toBuffer();
    frames.push(
      await sharp({
        create: {
          width: cw,
          height: ch,
          channels: 4,
          background: { r: 0, g: 0, b: 0, alpha: 0 }
        }
      }).composite([
        { input: avatarPng, left: 5, top: 0 },
        { input: templatePng, left: 0, top: 0 }
      ]).png().toBuffer()
    );
  }
  const buffer = await encodeGifFromPngFrames(sharp, frames, 60);
  return { buffer, mime: "image/gif", ext: "gif" };
}

const LOCS$1 = [
  { x: 4, y: 5, w: 53, h: 46 },
  { x: 7, y: 6, w: 50, h: 45 },
  { x: 6, y: 8, w: 50, h: 42 },
  { x: 7, y: 7, w: 50, h: 44 },
  { x: 4, y: 8, w: 53, h: 42 },
  { x: 7, y: 7, w: 52, h: 45 }
];
async function render$c(input) {
  const dir = resolveBqbSubdir("scratch_head", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-scratch-head: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: true, size: 68 });
  const frames = [];
  for (let i = 0; i < LOCS$1.length; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-scratch-head: 模板不存在 ${i}`);
    frames.push(await composeAvatarOverTemplate(sharp, tpl, avatarPng, LOCS$1[i]));
  }
  const buffer = await encodeGifFromPngFrames(sharp, frames, 100);
  return { buffer, mime: "image/gif", ext: "gif" };
}

const TARGET_LOCS = [
  { x: 39, y: 91, w: 75, h: 75 },
  { x: 49, y: 101, w: 75, h: 75 },
  { x: 67, y: 98, w: 75, h: 75 },
  { x: 55, y: 86, w: 75, h: 75 },
  { x: 61, y: 109, w: 75, h: 75 },
  { x: 65, y: 101, w: 75, h: 75 }
];
const SELF_LOCS = [
  { x: 102, y: 95, w: 70, h: 80, angle: 0 },
  { x: 108, y: 60, w: 50, h: 100, angle: 0 },
  { x: 97, y: 18, w: 65, h: 95, angle: 0 },
  { x: 65, y: 5, w: 75, h: 75, angle: -20 },
  { x: 95, y: 57, w: 100, h: 55, angle: -70 },
  { x: 109, y: 107, w: 65, h: 75, angle: 0 }
];
async function render$b(input) {
  const dir = resolveBqbSubdir("rub", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-rub: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const selfPng = await prepareAvatarPng(sharp, input.selfAvatar, { circle: true });
  const targetPng = await prepareAvatarPng(sharp, input.targetAvatar, { circle: true });
  const frames = [];
  for (let i = 0; i < 6; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-rub: 模板不存在 ${i}`);
    frames.push(
      await composeRubFrame(sharp, tpl, selfPng, targetPng, TARGET_LOCS[i], SELF_LOCS[i])
    );
  }
  const buffer = await encodeGifFromPngFrames(sharp, frames, 50);
  return { buffer, mime: "image/gif", ext: "gif" };
}

function escapeXml$1(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function parseDateParts(dateStr) {
  const raw = String(dateStr ?? "").trim();
  if (raw) {
    const m = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (m) {
      return { y: Number(m[1]), m: Number(m[2]), d: Number(m[3]) };
    }
    throw new Error("bqb-abstinence: 日期格式应为 YYYY-MM-DD");
  }
  const now = /* @__PURE__ */ new Date();
  return { y: now.getFullYear(), m: now.getMonth() + 1, d: now.getDate() };
}
function buildTextOverlaySvg(width, height, name, y, mo, d) {
  const font = "Noto Sans SC, Microsoft YaHei, PingFang SC, sans-serif";
  const safeName = escapeXml$1(name);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><text x="150" y="690" font-family="${font}" font-size="18" fill="#000">戒导人：<tspan text-decoration="underline">${safeName}</tspan></text><text x="150" y="780" font-family="${font}" font-size="20" fill="#000"><tspan text-decoration="underline">${y}</tspan>年<tspan text-decoration="underline"> ${mo} </tspan>月<tspan text-decoration="underline"> ${d} </tspan>日</text></svg>`;
  return Buffer.from(svg);
}
async function render$a(input) {
  const dir = resolveBqbSubdir("abstinence", input.dataPath, input.pluginDir);
  const basePath = path.join(dir, "base.png");
  const stampPath = path.join(dir, "stamp.png");
  if (!dir || !fs.existsSync(basePath) || !fs.existsSync(stampPath)) {
    throw new Error("bqb-abstinence: 素材不存在（需 base.png、stamp.png）");
  }
  const displayName = String(input.displayName ?? "").trim() || "戒导人";
  const { y, m, d } = parseDateParts(input.date);
  const sharp = await getBqbSharp();
  const baseMeta = await sharp(basePath).metadata();
  const cw = Math.max(1, Number(baseMeta.width) || 900);
  const ch = Math.max(1, Number(baseMeta.height) || 900);
  const avatarPng = await sharp(input.avatar).rotate().resize(270, 360, { fit: "inside", kernel: "linear" }).png().toBuffer();
  const textSvg = buildTextOverlaySvg(cw, ch, displayName, y, m, d);
  const buffer = await sharp(basePath).ensureAlpha().composite([
    { input: textSvg, left: 0, top: 0 },
    { input: avatarPng, left: 80, top: 380 },
    { input: stampPath, left: 310, top: 660 }
  ]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

const DEFAULT_TEXT = "走，跟我去二次元吧";
function escapeXml(text) {
  return String(text ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function buildTextSvg(width, height, text) {
  const font = "Noto Sans SC, Microsoft YaHei, PingFang SC, sans-serif";
  const safe = escapeXml(text);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><style>text{font-family:${font};fill:#fff;font-weight:600;}</style><text x="30" y="780" font-size="38">${safe}</text></svg>`;
  return Buffer.from(svg);
}
async function render$9(input) {
  const dir = resolveBqbSubdir("acg_entrance", input.dataPath, input.pluginDir);
  if (!dir) throw new Error("bqb-acg-entrance: 素材目录不存在");
  const tpl = path.join(dir, "0.png");
  if (!fs.existsSync(tpl)) throw new Error("bqb-acg-entrance: 模板不存在 0.png");
  const sharp = await getBqbSharp();
  const meta = await sharp(tpl).metadata();
  const w = Math.max(1, Number(meta.width) || 900);
  const h = Math.max(1, Number(meta.height) || 900);
  const photo = await sharp(input.avatar).rotate().resize(290, 410, { fit: "cover", position: "centre", kernel: "lanczos3" }).ensureAlpha().png().toBuffer();
  const text = String(input.text ?? "").trim() || DEFAULT_TEXT;
  const textSvg = buildTextSvg(w, h, text);
  const framePng = await sharp(tpl).ensureAlpha().composite([{ input: textSvg, left: 0, top: 0 }]).png().toBuffer();
  const buffer = await sharp({
    create: {
      width: w,
      height: h,
      channels: 4,
      background: { r: 255, g: 255, b: 255, alpha: 1 }
    }
  }).composite([
    { input: photo, left: 190, top: 265 },
    { input: framePng, left: 0, top: 0 }
  ]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

async function render$8(input) {
  const dir = resolveBqbSubdir("addiction", input.dataPath, input.pluginDir);
  if (!dir) throw new Error("bqb-addiction: 素材目录不存在");
  const tpl = path.join(dir, "0.png");
  if (!fs.existsSync(tpl)) throw new Error("bqb-addiction: 模板不存在 0.png");
  const sharp = await getBqbSharp();
  const photo = await sharp(input.avatar).rotate().resize(91, 91, { fit: "cover", position: "centre", kernel: "lanczos3" }).ensureAlpha().png().toBuffer();
  const buffer = await sharp(tpl).ensureAlpha().composite([{ input: photo, left: 0, top: 0 }]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

function pickDominantColors(data) {
  const buckets = Array.from({ length: 8 }, () => ({ r: 0, g: 0, b: 0, count: 0 }));
  let sampled = 0;
  for (let i = 0; i + 3 < data.length; i += 4) {
    const a = data[i + 3];
    if (a < 16) continue;
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const idx = r >> 7 << 2 | g >> 7 << 1 | b >> 7;
    const cur = buckets[idx];
    cur.r += r;
    cur.g += g;
    cur.b += b;
    cur.count += 1;
    sampled += 1;
  }
  const colors = buckets.filter((b) => b.count > 0 && b.count / Math.max(1, sampled) > 0.01).sort((a, b) => b.count - a.count).map((b) => `rgb(${Math.round(b.r / b.count)},${Math.round(b.g / b.count)},${Math.round(b.b / b.count)})`);
  return colors.length > 0 ? colors : ["rgb(255,255,255)"];
}
function makeSeedFromBuffer(buf) {
  let seed = 0;
  const len = Math.min(buf.length, 256);
  for (let i = 0; i < len; i++) {
    seed = seed * 131 + buf[i] >>> 0;
  }
  return seed || 1;
}
function nextRand(seed) {
  return seed * 1664525 + 1013904223 >>> 0;
}
function buildBlocksSvg(maskRaw, maskW, maskH, colors, seed0) {
  let seed = seed0 >>> 0;
  const blocks = [];
  const points = [];
  const x1 = 200;
  const y1 = 300;
  const x2 = 400;
  const y2 = 650;
  for (let tries = 0; tries < 1200 && points.length < 150; tries++) {
    seed = nextRand(seed);
    const x = x1 + seed % (x2 - x1 + 1);
    seed = nextRand(seed);
    const y = y1 + seed % (y2 - y1 + 1);
    if (x < 0 || y < 0 || x >= maskW || y >= maskH) continue;
    const idx = (y * maskW + x) * 4;
    const alpha = maskRaw[idx + 3] ?? 0;
    const r = maskRaw[idx] ?? 0;
    const g = maskRaw[idx + 1] ?? 0;
    const b = maskRaw[idx + 2] ?? 0;
    if (alpha < 8 || r < 8 && g < 8 && b < 8) continue;
    if (points.some((p) => Math.abs(x - p.x) < 13 && Math.abs(y - p.y) < 13)) continue;
    points.push({ x, y });
    seed = nextRand(seed);
    const color = colors[seed % colors.length];
    blocks.push(
      `<rect x="${x}" y="${y}" width="10" height="10" fill="${color}" transform="rotate(45 ${x} ${y})"/>`
    );
  }
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${maskW}" height="${maskH}">` + blocks.join("") + `</svg>`;
  return Buffer.from(svg);
}
async function render$7(input) {
  const dir = resolveBqbSubdir("dont_touch", input.dataPath, input.pluginDir);
  if (!dir) throw new Error("bqb-dont-touch: 素材目录不存在");
  const tpl = path.join(dir, "0.png");
  const mask = path.join(dir, "mask.png");
  if (!fs.existsSync(tpl)) throw new Error("bqb-dont-touch: 模板不存在 0.png");
  if (!fs.existsSync(mask)) throw new Error("bqb-dont-touch: 模板不存在 mask.png");
  const sharp = await getBqbSharp();
  const photo = await sharp(input.avatar).rotate().resize(250, 250, { fit: "contain", background: { r: 255, g: 255, b: 255, alpha: 0 } }).ensureAlpha().png().toBuffer();
  const colorSample = await sharp(photo).resize(200, 200, { fit: "inside" }).ensureAlpha().raw().toBuffer();
  const colors = pickDominantColors(colorSample);
  const maskMeta = await sharp(mask).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const blocksSvg = buildBlocksSvg(
    maskMeta.data,
    maskMeta.info.width,
    maskMeta.info.height,
    colors,
    makeSeedFromBuffer(input.avatar)
  );
  const buffer = await sharp(tpl).ensureAlpha().composite([
    { input: blocksSvg, left: 0, top: 0 },
    { input: photo, left: 25, top: 460 }
  ]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

function seededNext(seed) {
  return seed * 1664525 + 1013904223 >>> 0;
}
function makeSeed(buf) {
  let seed = 0;
  const len = Math.min(buf.length, 512);
  for (let i = 0; i < len; i++) seed = seed * 131 + buf[i] >>> 0;
  return seed || 1;
}
function buildDotSvg(width, height, dusts) {
  const circles = dusts.filter((d) => !d.dead && d.radius > 0).map((d) => `<circle cx="${d.x.toFixed(2)}" cy="${d.y.toFixed(2)}" r="${d.radius.toFixed(2)}" fill="#000"/>`).join("");
  return Buffer.from(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${circles}</svg>`
  );
}
async function render$6(input) {
  const sharp = await getBqbSharp();
  let image = sharp(input.avatar).rotate().ensureAlpha();
  const meta = await image.metadata();
  const maxWidth = 200;
  if ((meta.width || 0) > maxWidth) {
    image = image.resize({ width: maxWidth });
  }
  const basePng = await image.png().toBuffer();
  const info = await sharp(basePng).metadata();
  const width = Math.max(1, Number(info.width) || 1);
  const height = Math.max(1, Number(info.height) || 1);
  const raw = await sharp(basePng).ensureAlpha().raw().toBuffer();
  const centerX = width * 2 / 3;
  const centerY = height * 3 / 2;
  const radius = Math.sqrt(centerX * centerX + centerY * centerY);
  const step = radius / 24;
  const dusts = [];
  let seed = makeSeed(input.avatar);
  const frames = [];
  for (let i = 0; i < 35; i++) {
    if (i <= 9) {
      frames.push(basePng);
      continue;
    }
    if (i < 28) {
      const t = i - 9;
      const r1 = step * (t + 4);
      const r2 = step * (t + 5);
      const r3 = step * (t + 11);
      const pixelOverlays = [];
      for (let y = 0; y < height; y++) {
        for (let x = 0; x < width; x++) {
          const idx = (y * width + x) * 4;
          const a = raw[idx + 3] ?? 0;
          if (a === 0) continue;
          const dx0 = x - centerX;
          const dy0 = y - centerY;
          const dist = Math.sqrt(dx0 * dx0 + dy0 * dy0);
          if (dist <= r1) {
            continue;
          }
          if (dist <= r2) {
            pixelOverlays.push(`<rect x="${x}" y="${y}" width="1" height="1" fill="black"/>`);
            continue;
          }
          if (dist <= r3) {
            seed = seededNext(seed);
            const rand = (seed & 65535) / 65535;
            let factor = 0.5 + (dist - r2) / Math.max(1e-3, r3 - r2);
            factor = Math.max(0, Math.min(1, factor));
            factor *= 0.9 + 0.2 * rand;
            const gray = Math.max(
              0,
              Math.min(255, Math.round(((raw[idx] ?? 0) + (raw[idx + 1] ?? 0) + (raw[idx + 2] ?? 0)) / 3 * factor))
            );
            pixelOverlays.push(
              `<rect x="${x}" y="${y}" width="1" height="1" fill="rgb(${gray},${gray},${gray})" fill-opacity="${(a / 255).toFixed(3)}"/>`
            );
          } else {
            const rr = raw[idx] ?? 0;
            const gg = raw[idx + 1] ?? 0;
            const bb = raw[idx + 2] ?? 0;
            pixelOverlays.push(
              `<rect x="${x}" y="${y}" width="1" height="1" fill="rgb(${rr},${gg},${bb})" fill-opacity="${(a / 255).toFixed(3)}"/>`
            );
          }
        }
      }
      for (let r = Math.floor(r1); r < Math.floor(r2); r++) {
        for (let theta = 0; theta < 180; theta++) {
          const rad = theta * Math.PI / 180;
          const x = Math.floor(centerX + r * Math.cos(rad));
          const y = Math.floor(centerY - r * Math.sin(rad));
          if (x < 0 || x >= width || y < 0 || y >= height) continue;
          const idx = (y * width + x) * 4;
          const a = raw[idx + 3] ?? 0;
          if (a === 0) continue;
          seed = seededNext(seed);
          if ((seed & 65535) / 65535 < 0.1) {
            const rr = Math.max(1, r);
            dusts.push({
              x,
              y,
              vx: 0,
              vy: 0,
              dx: (x - centerX) / rr,
              dy: 1.5 * (y - centerY) / rr,
              radius: 1 + (seed >>> 16 & 65535) / 65535 * 2,
              dead: false
            });
          }
        }
      }
      for (const dot of dusts) {
        if (dot.dead) continue;
        const a = 0.02 * step / Math.max(1, dot.radius);
        dot.vx += a * dot.dx;
        dot.vy += a * dot.dy;
        dot.x += dot.vx;
        dot.y += dot.vy;
        seed = seededNext(seed);
        if ((seed & 65535) / 65535 < 0.25) dot.radius -= 1;
        if (dot.radius <= 0 || dot.x + dot.radius < 0 || dot.x - dot.radius > width || dot.y + dot.radius < 0 || dot.y - dot.radius > height) {
          dot.dead = true;
        }
      }
      const frameSvg = Buffer.from(
        `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">${pixelOverlays.join("")}</svg>`
      );
      const dustSvg = buildDotSvg(width, height, dusts);
      frames.push(
        await sharp({
          create: {
            width,
            height,
            channels: 4,
            background: { r: 0, g: 0, b: 0, alpha: 0 }
          }
        }).composite([
          { input: frameSvg, left: 0, top: 0 },
          { input: dustSvg, left: 0, top: 0 }
        ]).png().toBuffer()
      );
    } else {
      for (const dot of dusts) {
        if (dot.dead) continue;
        const a = 0.02 * step / Math.max(1, dot.radius);
        dot.vx += a * dot.dx;
        dot.vy += a * dot.dy;
        dot.x += dot.vx;
        dot.y += dot.vy;
        seed = seededNext(seed);
        if ((seed & 65535) / 65535 < 0.25) dot.radius -= 1;
        if (dot.radius <= 0 || dot.x + dot.radius < 0 || dot.x - dot.radius > width || dot.y + dot.radius < 0 || dot.y - dot.radius > height) {
          dot.dead = true;
        }
      }
      const dustSvg = buildDotSvg(width, height, dusts);
      frames.push(
        await sharp({
          create: {
            width,
            height,
            channels: 4,
            background: { r: 0, g: 0, b: 0, alpha: 0 }
          }
        }).composite([{ input: dustSvg, left: 0, top: 0 }]).png().toBuffer()
      );
    }
  }
  const buffer = await sharp({
    create: {
      width,
      height: height * frames.length,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 0 },
      pageHeight: height
    }
  }).composite(frames.map((input2, i) => ({ input: input2, left: 0, top: i * height }))).gif({ delay: 80, loop: 0, effort: 1 }).toBuffer();
  return { buffer, mime: "image/gif", ext: "gif" };
}

const LOCS = [
  { x: 135, y: 240, w: 138, h: 47 },
  { x: 135, y: 240, w: 138, h: 47 },
  { x: 150, y: 190, w: 105, h: 95 },
  { x: 150, y: 190, w: 105, h: 95 },
  { x: 148, y: 188, w: 106, h: 98 },
  { x: 146, y: 196, w: 110, h: 88 },
  { x: 145, y: 223, w: 112, h: 61 },
  { x: 145, y: 223, w: 112, h: 61 }
];
async function render$5(input) {
  const dir = resolveBqbSubdir("pound", input.dataPath, input.pluginDir);
  if (!dir || !fs.existsSync(dir)) {
    throw new Error("bqb-pound: 素材目录不存在");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: false });
  const frames = [];
  let outW = 0;
  let outH = 0;
  for (let i = 0; i < 8; i++) {
    const tpl = templatePath(dir, i, "png");
    if (!fs.existsSync(tpl)) throw new Error(`bqb-pound: 模板不存在 ${i}`);
    if (!outW || !outH) {
      const meta = await sharp(tpl).metadata();
      outW = Math.max(1, Number(meta.width) || 1);
      outH = Math.max(1, Number(meta.height) || 1);
    }
    const { x, y, w, h } = LOCS[i] ?? LOCS[0];
    const avatarResized = await sharp(avatarPng).resize(Math.max(1, Math.floor(w)), Math.max(1, Math.floor(h)), {
      fit: "fill",
      kernel: "lanczos3"
    }).png().toBuffer();
    const templateBuf = await sharp(tpl).ensureAlpha().png().toBuffer();
    const frame = await sharp({
      create: {
        width: outW,
        height: outH,
        channels: 4,
        background: { r: 255, g: 255, b: 255, alpha: 1 }
      }
    }).composite([
      { input: avatarResized, left: Math.floor(x), top: Math.floor(y) },
      { input: templateBuf, left: 0, top: 0 }
    ]).png().toBuffer();
    frames.push(frame);
  }
  const buffer = await encodeGifFromPngFrames(sharp, frames, 50);
  return { buffer, mime: "image/gif", ext: "gif" };
}

async function render$4(input) {
  const kind = "sold_out";
  const dir = resolveBqbSubdir(kind, input.dataPath, input.pluginDir);
  const tpl = path.join(dir, "0.png");
  if (!dir || !fs.existsSync(tpl)) {
    throw new Error("bqb-sold_out: 素材不存在（需 sold_out/0.png）");
  }
  const sharp = await getBqbSharp();
  const rotated = sharp(input.avatar).rotate().ensureAlpha();
  const meta0 = await rotated.metadata();
  const w0 = Number(meta0.width) || 0;
  const h0 = Number(meta0.height) || 0;
  let avatarResized = rotated;
  if (w0 > h0) {
    avatarResized = rotated.resize({ height: 600, kernel: "lanczos3" });
  } else {
    avatarResized = rotated.resize({ width: 600, kernel: "lanczos3" });
  }
  const avatarPng = await avatarResized.png().toBuffer();
  const meta = await sharp(avatarPng).metadata();
  const w = Math.max(1, Number(meta.width) || 1);
  const h = Math.max(1, Number(meta.height) || 1);
  const iconPng = await sharp(tpl).ensureAlpha().png().toBuffer();
  const iconMeta = await sharp(iconPng).metadata();
  const iconW = Math.max(1, Number(iconMeta.width) || 1);
  const iconH = Math.max(1, Number(iconMeta.height) || 1);
  const overlay = await sharp({
    create: {
      width: w,
      height: h,
      channels: 4,
      background: { r: 0, g: 0, b: 0, alpha: 80 / 255 }
    }
  }).png().toBuffer();
  const buffer = await sharp(avatarPng).ensureAlpha().composite([
    { input: overlay, left: 0, top: 0 },
    { input: iconPng, left: Math.floor((w - iconW) / 2), top: Math.floor((h - iconH) / 2) }
  ]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

async function render$3(input) {
  const dir = resolveBqbSubdir("taunt", input.dataPath, input.pluginDir);
  const tpl = path.join(dir, "0.png");
  if (!dir || !fs.existsSync(tpl)) {
    throw new Error("bqb-taunt: 素材不存在（需 taunt/0.png）");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: false, size: 230 });
  const buffer = await sharp(tpl).ensureAlpha().composite([{ input: avatarPng, left: 245, top: 245 }]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

async function render$2(input) {
  const dir = resolveBqbSubdir("think_what", input.dataPath, input.pluginDir);
  const tpl = path.join(dir, "0.png");
  if (!dir || !fs.existsSync(tpl)) {
    throw new Error("bqb-think-what: 素材不存在（需 think_what/0.png）");
  }
  const sharp = await getBqbSharp();
  const meta = await sharp(tpl).metadata();
  const w = Math.max(1, Number(meta.width) || 1);
  const h = Math.max(1, Number(meta.height) || 1);
  const photo = await sharp(input.avatar).rotate().resize(534, 493, { fit: "cover", position: "centre", kernel: "lanczos3" }).ensureAlpha().png().toBuffer();
  const framePng = await sharp(tpl).ensureAlpha().png().toBuffer();
  const buffer = await sharp({
    create: {
      width: w,
      height: h,
      channels: 4,
      background: { r: 255, g: 255, b: 255, alpha: 1 }
    }
  }).composite([
    { input: photo, left: 530, top: 0 },
    { input: framePng, left: 0, top: 0 }
  ]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

async function render$1(input) {
  const dir = resolveBqbSubdir("what_i_want_to_do", input.dataPath, input.pluginDir);
  const tpl = path.join(dir, "0.png");
  if (!dir || !fs.existsSync(tpl)) {
    throw new Error("bqb-what-i-want-to-do: 素材不存在（需 what_i_want_to_do/0.png）");
  }
  const sharp = await getBqbSharp();
  const avatarPng = await prepareAvatarPng(sharp, input.avatar, { circle: true });
  const avatarFit = await sharp(avatarPng).resize(270, 270, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer();
  const buffer = await sharp(tpl).ensureAlpha().composite([{ input: avatarFit, left: 350, top: 590 }]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

async function render(input) {
  const dir = resolveBqbSubdir("you_dont_get", input.dataPath, input.pluginDir);
  const tpl = path.join(dir, "0.png");
  if (!dir || !fs.existsSync(tpl)) {
    throw new Error("bqb-you-dont-get: 素材不存在（需 you_dont_get/0.png）");
  }
  const sharp = await getBqbSharp();
  const meta = await sharp(tpl).metadata();
  const w = Math.max(1, Number(meta.width) || 1);
  const h = Math.max(1, Number(meta.height) || 1);
  const photo = await sharp(input.avatar).rotate().resize(142, 139, { fit: "cover", position: "centre", kernel: "lanczos3" }).ensureAlpha().png().toBuffer();
  const framePng = await sharp(tpl).ensureAlpha().png().toBuffer();
  const buffer = await sharp({
    create: {
      width: w,
      height: h,
      channels: 4,
      background: { r: 255, g: 255, b: 255, alpha: 1 }
    }
  }).composite([
    { input: photo, left: 217, top: 181 },
    { input: framePng, left: 0, top: 0 }
  ]).png().toBuffer();
  return { buffer, mime: "image/png", ext: "png" };
}

function abToBuffer(v) {
  if (Buffer.isBuffer(v)) return v;
  if (v instanceof ArrayBuffer) return Buffer.from(v);
  if (ArrayBuffer.isView(v)) {
    const view = v;
    return Buffer.from(view.buffer, view.byteOffset, view.byteLength);
  }
  throw new Error("无效的图片 Buffer");
}
function toTransferable(buf) {
  const ab = new ArrayBuffer(buf.byteLength);
  new Uint8Array(ab).set(buf);
  return ab;
}
async function dispatchCard(kind, payload) {
  const logger = void 0;
  let b64 = null;
  switch (kind) {
    case "menu":
      b64 = await renderMenuWithSharpImpl(
        String(payload.pluginDir || ""),
        String(payload.dataPath || ""),
        payload.options || {});
      break;
    case "api-menu":
      b64 = await renderApiInterfaceMenuWithSharpImpl(payload.options || {});
      break;
    case "fortune":
      b64 = await renderFortuneWithSharpImpl(payload.options || {}, logger);
      break;
    case "status":
      b64 = await renderStatusWithSharpImpl(payload.options || {}, logger);
      break;
    case "signin":
      b64 = await renderSignInWithSharpImpl(payload.options || {});
      break;
    case "wallet":
      b64 = await renderWalletWithSharpImpl(payload.options || {}, logger);
      break;
    case "shop":
      b64 = await renderShopWithSharpImpl(payload.options || {});
      break;
    case "fish-basket":
      b64 = await renderFishBasketWithSharpImpl(payload.options || {}, logger);
      break;
    case "music-list":
      b64 = await renderMusicListWithSharpImpl(payload.options || {});
      break;
    case "join-identity":
      b64 = await renderJoinIdentityWithSharpImpl(payload.options || {}, logger);
      break;
    default:
      throw new Error(`未知卡片 kind=${kind}`);
  }
  if (!b64) throw new Error(`渲染失败 kind=${kind}`);
  return Buffer.from(b64, "base64");
}
async function dispatchBqb(payload) {
  const subKind = String(payload.subKind || "").trim();
  const dataPath = String(payload.dataPath || "");
  const pluginDir = String(payload.pluginDir || "");
  const commonBase = { dataPath, pluginDir };
  let result;
  if (subKind === "rub") {
    result = await render$b({
      selfAvatar: abToBuffer(payload.selfAvatar),
      targetAvatar: abToBuffer(payload.targetAvatar),
      ...commonBase
    });
  } else if (subKind === "abstinence") {
    result = await render$a({
      avatar: abToBuffer(payload.avatar),
      displayName: String(payload.displayName || ""),
      date: payload.date != null ? String(payload.date) : void 0,
      ...commonBase
    });
  } else {
    const avatar = abToBuffer(payload.avatar);
    const common = { avatar, ...commonBase };
    if (subKind === "crawl") result = await render$j(common);
    else if (subKind === "play") result = await render$i(common);
    else if (subKind === "bite") result = await render$h(common);
    else if (subKind === "petpet") result = await render$g(common);
    else if (subKind === "eat") result = await render$f(common);
    else if (subKind === "suck") result = await render$e(common);
    else if (subKind === "jiujiu") result = await render$d(common);
    else if (subKind === "scratch_head") result = await render$c(common);
    else if (subKind === "acg_entrance") result = await render$9(common);
    else if (subKind === "addiction") result = await render$8(common);
    else if (subKind === "dont_touch") result = await render$7(common);
    else if (subKind === "fade_away") result = await render$6(common);
    else if (subKind === "pound") result = await render$5(common);
    else if (subKind === "sold_out") result = await render$4(common);
    else if (subKind === "taunt") result = await render$3(common);
    else if (subKind === "think_what") result = await render$2(common);
    else if (subKind === "what_i_want_to_do") result = await render$1(common);
    else if (subKind === "you_dont_get") result = await render(common);
    else throw new Error(`未知 bqb subKind=${subKind}`);
  }
  return result;
}
async function handleJob(msg) {
  const id = Number(msg?.id);
  try {
    if (msg.paths) configureSharpRuntimePaths(msg.paths);
    const kind = String(msg.kind || "");
    const payload = msg.payload && typeof msg.payload === "object" ? msg.payload : {};
    if (kind === "bqb") {
      const result = await dispatchBqb(payload);
      const buffer2 = toTransferable(result.buffer);
      parentPort.postMessage(
        { id, ok: true, buffer: buffer2, mime: result.mime, ext: result.ext },
        [buffer2]
      );
      return;
    }
    const png = await dispatchCard(kind, payload);
    const buffer = toTransferable(png);
    parentPort.postMessage(
      { id, ok: true, buffer, mime: "image/png", ext: "png" },
      [buffer]
    );
  } catch (e) {
    parentPort.postMessage({
      id,
      ok: false,
      error: String(e?.message || e || "Sharp Worker 渲染失败")
    });
  }
}
if (!parentPort) {
  throw new Error("sharp-worker 须由 worker_threads 启动");
}
parentPort.on("message", (msg) => {
  void handleJob(msg);
});
